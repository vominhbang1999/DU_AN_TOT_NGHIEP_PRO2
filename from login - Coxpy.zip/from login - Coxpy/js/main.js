$(document).ready(function () {
    $('#dn').click(function (e) { 
        e.preventDefault();
        $('.from-dn').toggleClass('change');
        $('.momo').addClass('changemomo');
    });
    $('#dk').click(function (e) { 
        e.preventDefault();
        $('.from-dn').removeClass('change');
        $('.from-dk').toggleClass('change1');
        $('.momo').addClass('changemomo');
        
    });
    $('.close').click(function (e) { 
        e.preventDefault();
        $('.from-dn').removeClass('change');
        $('.momo').removeClass('changemomo');
    });
    $('.from-dk .close').click(function (e) { 
        e.preventDefault();
        $('.from-dk').removeClass('change1');
        $('.momo').removeClass('changemomo');
    });
    $('.momo').click(function (e) { 
        e.preventDefault();
        $(this).removeClass('changemomo');
        $('.from-dn').removeClass('change');
        $('.from-dk').removeClass('change1');
    });
    $('#tk').click(function (e) { 
        $('.from-dn').removeClass('change');
        $('.from-dk').addClass('change1');
    });
    $('#ctk').click(function (e) { 
        e.preventDefault();
        $('.from-dk').removeClass('change1');
        $('.from-dn').addClass('change');
    });
});