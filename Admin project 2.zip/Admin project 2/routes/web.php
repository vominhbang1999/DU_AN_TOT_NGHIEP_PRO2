<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//admin
Route::get('/', 'AdminController@index');

Route::get('/dashboard', 'AdminController@show_dashboard');
Route::get('/logout', 'AdminController@logout');
Route::post('/admin-dashboard', 'AdminController@dashboard');

//singer
Route::get('/add-list-sing', 'ListController@add_list_sing');
Route::get('/all-list-sing', 'ListController@all_list_sing');

//ca sĩ
Route::get('insert', 'quanly@form_insert');

Route::get('store', 'quanly@store');

Route::get('ql_casi', 'quanly@index');

Route::get('edit_casi/{id}', 'quanly@form_edit');

Route::post('save/{id}', 'quanly@update');

Route::get('delete_casi/{id}', 'quanly@delete');


