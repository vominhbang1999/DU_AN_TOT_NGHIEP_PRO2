<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//admin

Route::get('/', 'AdminController@index');
Route::get('/admin', 'AdminController@login');
Route::get('/dashboard', 'AdminController@show_dashboard');
Route::get('/logout', 'AdminController@logout');
Route::post('/admin_dashboard', 'AdminController@dashboard');


//ca sĩ

Route::get('insert_casi', 'quanlycasi@form_insert');

Route::get('store_casi', 'quanlycasi@store');

Route::get('ql_casi', 'quanlycasi@index');

Route::get('edit_casi/{id}', 'quanlycasi@form_edit');

Route::post('save_casi/{id}', 'quanlycasi@update');

Route::get('delete_casi/{id}', 'quanlycasi@delete');


// Album

Route::get('insert_album', 'quanlyalbum@form_insert');

Route::get('store_album', 'quanlyalbum@store');

Route::get('ql_album', 'quanlyalbum@index');

Route::get('edit_album/{id}', 'quanlyalbum@form_edit');

Route::post('save_album/{id}', 'quanlyalbum@update');

Route::get('delete_album/{id}', 'quanlyalbum@delete');


// Tintuc

Route::get('insert_tintuc', 'quanlytintuc@form_insert');

Route::get('store_tintuc', 'quanlytintuc@store');

Route::get('ql_tintuc', 'quanlytintuc@index');

Route::get('edit_tintuc/{id}', 'quanlytintuc@form_edit');

Route::post('save_tintuc/{id}', 'quanlytintuc@update');

Route::get('delete_tintuc/{id}', 'quanlytintuc@delete');


// Nhac si

Route::get('insert_nhacsi', 'quanlynhacsi@form_insert');

Route::get('store_nhacsi', 'quanlynhacsi@store');

Route::get('ql_nhacsi', 'quanlynhacsi@index');

Route::get('edit_nhacsi/{id}', 'quanlynhacsi@form_edit');

Route::post('save_nhacsi/{id}', 'quanlynhacsi@update');

Route::get('delete_nhacsi/{id}', 'quanlynhacsi@delete');


// The loai nhac

Route::get('insert_theloainhac', 'quanlytheloainhac@form_insert');

Route::get('store_theloainhac', 'quanlytheloainhac@store');

Route::get('ql_theloainhac', 'quanlytheloainhac@index');

Route::get('edit_theloainhac/{id}', 'quanlytheloainhac@form_edit');

Route::post('save_theloainhac/{id}', 'quanlytheloainhac@update');

Route::get('delete_theloainhac/{id}', 'quanlytheloainhac@delete');


// Bai hat

Route::get('insert_baihat', 'quanlybaihat@form_insert');

Route::get('store_baihat', 'quanlybaihat@store');

Route::get('ql_baihat', 'quanlybaihat@index');

Route::get('edit_baihat/{id}', 'quanlybaihat@form_edit');

Route::post('save_baihat/{id}', 'quanlybaihat@update');

Route::get('delete_baihat/{id}', 'quanlybaihat@delete');