<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//admin

Route::get('/', 'AdminController@index');

Route::get('/dashboard', 'AdminController@show_dashboard');
Route::get('/logout', 'AdminController@logout');
Route::post('/admin-dashboard', 'AdminController@dashboard');

//ca sĩ

Route::get('insert_cs', 'quanly@form_insert');

Route::get('store', 'quanly@store');

Route::get('ql_casi', 'quanly@index');

Route::get('edit_casi/{id}', 'quanly@form_edit');

Route::post('save_cs/{id}', 'quanly@update');

Route::get('delete_casi/{id}', 'quanly@delete');

//Album

Route::get('insert_ab', 'quanlyalbum@form_insert');

Route::get('store', 'quanlyalbum@store');

Route::get('ql_album', 'quanlyalbum@index');

Route::get('edit_album/{id}', 'quanlyalbum@form_edit');

Route::post('save_ab/{id}', 'quanlyalbum@update');

Route::get('delete_album/{id}', 'quanlyalbum@delete');

//nhạc sĩ

Route::get('insert_nhacsi', 'quanlynhacsi@form_insert');

Route::get('store', 'quanlynhacsi@store');

Route::get('ql_nhacsi', 'quanlynhacsi@index');

Route::get('edit_nhacsi/{id}', 'quanlynhacsi@form_edit');

Route::post('save_nhacsi/{id}', 'quanlynhacsi@update');

Route::get('delete_nhacsi/{id}', 'quanlynhacsi@delete');

//Thể loại nhạc

Route::get('insert_tln', 'quanlytln@form_insert');

Route::get('store', 'quanlytln@store');

Route::get('ql_tln', 'quanlytln@index');

Route::get('edit_tln/{id}', 'quanlytln@form_edit');

Route::post('save_tln/{id}', 'quanlytln@update');

Route::get('delete_tln/{id}', 'quanlytln@delete');



