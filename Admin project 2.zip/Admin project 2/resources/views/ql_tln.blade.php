@extends('admin_layout')
@section('admin_content')
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách thể loại nhạc
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td >Id_theloainhac</td>
            <td>Tên thể loại nhạc</td>
            <td>Hình</td>
            <td>Mô tả</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        @foreach($emp2 as $emp3)
          <tr>
            <td><span class="text-ellipsis">{{$emp3->id_theloainhac}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->ten_theloainhac}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->hinh_theloainhac}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->mota_theloainhac}}</span></td>
            <td>
                <a href="{{URL::to('/edit_tln/'.$emp3->id_theloainhac)}}" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a onclick="return confirm('Are you sure to delete?')" href="{{URL::to('/delete_tln/'.$emp3->id_theloainhac)}}" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
@endsection