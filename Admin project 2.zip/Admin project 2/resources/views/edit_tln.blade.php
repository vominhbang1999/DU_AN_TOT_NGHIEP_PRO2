@extends('admin_layout')
@section('admin_content')
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật thể loại nhạc
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_tln/{{$emp->id_theloainhac}}' method="post">
                    {{csrf_field()}}
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên thể loại nhạc</label>
                            <input type="text" class="form-control" name='ten_theloainhac' value={{$emp->ten_theloainhac}} id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputFile">Hình thể loại nhạc</label>
                            <input type="file" name='hinh_theloainhac' value={{$emp->hinh_theloainhac}} id="exampleInputFile">
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Mô tả thể loại nhạc</label>
                            <div >
                                <textarea class="form-control" id="ccomment" value={{$emp->mota_theloainhac}} name='mota_theloainhac' required=""></textarea>
                            </div>
                        </div>                 
                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

