@extends('admin.admin_layout')
@section('admin.admin_content')
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách Bài hát
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td >Id_baihat</td>
            <td>Tên Bài hát</td>
            <td>Lời bài hát</td>
            <td>Bài hát hot</td>
            <td>Link bài hát</td>
            <td>Mô tả bài hát</td>
            <td>Ngày cập nhật</td>
            <td>Số lần nghe</td>
            <td>Số lần tải</td>
            <td>Play list</td>
            <td>Số lần yêu thích</td>
            <td>id_theloainhac</td>
            <td>id_album</td>
            <td>id_casi</td>
            <td>id_nhacsi</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        @foreach($emp2 as $emp3)
          <tr>
            <td><span class="text-ellipsis">{{$emp3->id_baihat}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->ten_baihat}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->loi_baihat}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->hot_baihat}} ★</span></td>
            <td><span class="text-ellipsis">{{$emp3->link_baihat}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->mota_baihat}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->ngaycapnhat}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->solannghe}} lần</span></td>
            <td><span class="text-ellipsis">{{$emp3->solantai}} lần</span></td>
            <td><span class="text-ellipsis">{{$emp3->playlist}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->solanyeuthich}} lần</span></td>
            <td><span class="text-ellipsis">{{$emp3->id_theloainhac}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->id_album}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->id_casi}}</span></td>
            <td><span class="text-ellipsis">{{$emp3->id_nhacsi}}</span></td>
            <td>
                <a href="{{URL::to('/edit_baihat/'.$emp3->id_baihat)}}" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a onclick="return confirm('Bạn có muốn xóa không?')" href="{{URL::to('/delete_baihat/'.$emp3->id_baihat)}}" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
@endsection