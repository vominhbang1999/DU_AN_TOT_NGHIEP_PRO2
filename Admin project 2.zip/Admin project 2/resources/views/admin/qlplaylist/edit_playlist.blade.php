@extends('admin.admin_layout')
@section('admin.admin_content')
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật Tin tức
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_playlist/{{$emp->id_playlist}}' method="post">
                    {{csrf_field()}}
                        <div class="form-group ">
                            <label for="comment">id bài hát</label>
                            <div >
                                <input type="number" class="form-control" id="comment" name='id_baihat' value={{$emp->id_baihat}}  />
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên</label>
                            <input type="text" class="form-control" name='ten_playlist' value={{$emp->ten_playlist}} >
                        </div>
    
                        
                        <div class="form-group">
                            <label for="exampleInputFile">Hình</label>
                            <input type="file" name='hinhanh_playlist' value={{$emp->hinhanh_playlist}} id="exampleInputFile">
                        </div>
                        
                        <div class="form-group ">
                            <label for="ccomment">Mô tả</label>
                            <div >
                                <textarea class="form-control" id="ccomment" value={{$emp->mota_playlist}} name='mota_playlist' required=""></textarea>
                            </div>
                        </div>

                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

