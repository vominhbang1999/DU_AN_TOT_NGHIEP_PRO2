@extends('admin.admin_layout')
@section('admin.admin_content')
<h1 class="text-center" style="color: white;"> Trang quản lý Music website </h1>
@endsection

