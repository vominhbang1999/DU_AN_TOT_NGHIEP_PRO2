@extends('admin.admin_layout')
@section('admin.admin_content')
<h3>Chào mừng đến với Admin</h3>
@endsection