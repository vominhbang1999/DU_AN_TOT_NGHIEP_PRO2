<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_baihat extends Model
{
    protected $primaryKey='id_baihat';
        protected $table='baihat';
        protected $filltable=array('ten_baihat','loi_baihat','hot_baihat','link_baihat','mota_baihat','ngaycapnhat','solannghe','solantai','playlist','solanyeuthich','id_theloainhac','id_album','id_casi','id_nhacsi');
}
