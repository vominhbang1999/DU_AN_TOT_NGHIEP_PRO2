<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_tintuc extends Model
{
    protected $primaryKey='id_tintuc';
    protected $table='tintuc';
    protected $filltable=array('title_tintuc','tintuc_hot','noidung_tintuc','hinhanh_tintuc','ngaydang_tintuc','luotxem');
}
