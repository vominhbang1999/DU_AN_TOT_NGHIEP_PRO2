<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_playlist extends Model
{
    protected $primaryKey='id_playlist';
    protected $table='playlist';
    protected $filltable=array('id_baihat','hinhanh_playlist','ten_playlist','hinhanh_playlist','mota_playlist');
}
