<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_tloainhac extends Model
{
    protected $primaryKey='id_theloainhac';
    protected $table='theloainhac';
    protected $filltable=array('ten_theloainhac','hinhanh_theloainhac','mota_theloainhac');
}
