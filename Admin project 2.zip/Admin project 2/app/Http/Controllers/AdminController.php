<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use DB;
use Session;
use App\Http\Requests;
session_start();

class AdminController extends Controller
{
    public function index(){
        return view('admin_login');
    }
    public function show_dashboard(){
        return view('dashboard');
    }
    public function dashboard(Request $request){
        $email_admin = $request->input('email_admin');
		$password_admin = $request->input('password_admin');

        $result = DB::table('admin')->where('email_admin',$email_admin)->where('password_admin',$password_admin)->first();
        if($result){
            Session::put('name_admin',$result->name_admin);
            Session::put('id_admin',$result->id_admin);
            return Redirect::to('/dashboard');
        }else{
            Session::put('message','Email hoặc password không đúng');
            return Redirect::to('/');
        }
    }
    public function logout(){
        Session::put('name_admin',null);
        Session::put('id_admin',null);
        return Redirect::to('/');
    }
}
