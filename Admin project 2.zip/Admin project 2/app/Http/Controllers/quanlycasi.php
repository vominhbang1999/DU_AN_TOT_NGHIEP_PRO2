<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emp;
use Session;
use App\Http\Requests;
use DB;
use Illuminate\Support\Facades\Redirect;
Session_start();
class quanlycasi extends Controller
{
    
     // login
     public function AuthLogin(){
        $id_admin = Session::get('id_admin');
        if($id_admin){
            return Redirect::to('/dashboard');
        }else{
            return Redirect::to('/')->send();
        }
    }

    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
        $this -> AuthLogin();
         $emp1 = emp::all();
         return view('admin.qlcasi.ql_casi')->with('emp2',$emp1);
     }




    // HÀM INSERT 
    public function form_insert()
     {
        $this -> AuthLogin();
         return view('admin.qlcasi.insert_casi');
     }
     public function store(Request $request)
     {
        $this -> AuthLogin();
         $this->validate($request,[
            'hoten_casi'=>'required',
            'hot_casi'=>'required',
            'hinh_casi'=>'required',
            'gioithieu_casi'=>'required',
         ]);

         $emps= new emp;
         $emps->hoten_casi = $request->input('hoten_casi');
         $emps->hot_casi = $request->input('hot_casi');
         $emps->hinh_casi = $request->input('hinh_casi');
         $emps->gioithieu_casi = $request->input('gioithieu_casi');
         $emps->save();

         return redirect('ql_casi');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $this -> AuthLogin();
        $emps = emp::find($id);
        return view('admin.qlcasi.edit_casi')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this -> AuthLogin();
        $this->validate($request,[
           'hoten_casi'=>'required',
           'hot_casi'=>'required',
           'hinh_casi'=>'required',
           'gioithieu_casi'=>'required'
        ]);

        $emps= emp::find($id);

        $emps->hoten_casi = $request->input('hoten_casi');
        $emps->hot_casi = $request->input('hot_casi');
        $emps->hinh_casi = $request->input('hinh_casi');
        $emps->gioithieu_casi = $request->input('gioithieu_casi');

        $emps->save();

        return redirect('ql_casi');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $this -> AuthLogin();
        $emps = emp::find($id);
        $emps->delete();

        return redirect('ql_casi');
        
    } 

    
    
}
