<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emp_playlist;

class quanlyplaylist extends Controller
{
    
    

    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
         $emp1 = emp_playlist::all();
         return view('admin.qlplaylist.ql_playlist')->with('emp2',$emp1);
     }




    // HÀM INSERT 
    public function form_insert()
     {
         return view('admin.qlplaylist.insert_playlist');
     }
     public function store(Request $request)
     {
         $this->validate($request,[
            'id_baihat'=>'required',
            'hinhanh_playlist'=>'required',
            'ten_playlist'=>'required',
            'mota_playlist'=>'required'
         ]);

         $emps= new emp_playlist;
         $emps->id_baihat = $request->input('id_baihat');
         $emps->hinhanh_playlist = $request->input('hinhanh_playlist');
         $emps->ten_playlist = $request->input('ten_playlist');
         $emps->mota_playlist = $request->input('mota_playlist');
         $emps->save();

         return redirect('ql_playlist');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $emps = emp_playlist::find($id);
        return view('admin.qlplaylist.edit_playlist')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'id_baihat'=>'required',
            'hinhanh_playlist'=>'required',
            'ten_playlist'=>'required',
            'mota_playlist'=>'required'
        ]);

        $emps= emp_playlist::find($id);

        $emps->id_baihat = $request->input('id_baihat');
        $emps->hinhanh_playlist = $request->input('hinhanh_playlist');
        $emps->ten_playlist = $request->input('ten_playlist');
        $emps->mota_playlist = $request->input('mota_playlist');

        $emps->save();

        return redirect('ql_playlist');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $emps = emp_playlist::find($id);
        $emps->delete();

        return redirect('ql_playlist');
        
    } 

    
    
}
