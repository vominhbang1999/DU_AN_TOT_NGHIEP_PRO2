<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emp_baihat;
use Session;
use App\Http\Requests;
use DB;
use Illuminate\Support\Facades\Redirect;
Session_start();
class quanlybaihat extends Controller
{
    
     // login
     public function AuthLogin(){
        $id_admin = Session::get('id_admin');
        if($id_admin){
            return Redirect::to('/dashboard');
        }else{
            return Redirect::to('/')->send();
        }
    }

    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
        $this -> AuthLogin();
         $emp1 = emp_baihat::all();
         return view('admin.qlbaihat.ql_baihat')->with('emp2',$emp1);
     }




    // HÀM INSERT 
    public function form_insert()
     {
        $this -> AuthLogin();
         return view('admin.qlbaihat.insert_baihat');
     }
     public function store(Request $request)
     {
        $this -> AuthLogin();
         $this->validate($request,[
            'ten_baihat'=>'required',
            'loi_baihat'=>'required',
            'hot_baihat'=>'required',
            'link_baihat'=>'required',
            'mota_baihat'=>'required',
            'ngaycapnhat'=>'required',
            'solannghe'=>'required',
            'solantai'=>'required',
            'playlist'=>'required',
            'solanyeuthich'=>'required',
            'id_theloainhac'=>'required',
            'id_album'=>'required',
            'id_casi'=>'required',
            'id_nhacsi'=>'required'
         ]);

         $emps= new emp_baihat;
         
         $emps->ten_baihat      = $request->input('ten_baihat');
         $emps->loi_baihat      = $request->input('loi_baihat');
         $emps->hot_baihat      = $request->input('hot_baihat');
         $emps->link_baihat     = $request->input('link_baihat');
         $emps->mota_baihat     = $request->input('mota_baihat');
         $emps->ngaycapnhat     = $request->input('ngaycapnhat');
         $emps->solannghe       = $request->input('solannghe');
         $emps->solantai        = $request->input('solantai');
         $emps->playlist        = $request->input('playlist');
         $emps->solanyeuthich   = $request->input('solanyeuthich');
         $emps->id_theloainhac  = $request->input('id_theloainhac');
         $emps->id_album        = $request->input('id_album');
         $emps->id_casi         = $request->input('id_casi');
         $emps->id_nhacsi       = $request->input('id_nhacsi');
         $emps->save();

         return redirect('ql_baihat');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $this -> AuthLogin();
        $emps = emp_baihat::find($id);
        return view('admin.qlbaihat.edit_baihat')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this -> AuthLogin();
        $this->validate($request,[
            'ten_baihat'=>'required',
            'loi_baihat'=>'required',
            'hot_baihat'=>'required',
            'link_baihat'=>'required',
            'mota_baihat'=>'required',
            'ngaycapnhat'=>'required',
            'solannghe'=>'required',
            'solantai'=>'required',
            'playlist'=>'required',
            'solanyeuthich'=>'required',
            'id_theloainhac'=>'required',
            'id_album'=>'required',
            'id_casi'=>'required',
            'id_nhacsi'=>'required'
        ]);

        $emps= emp_baihat::find($id);

        $emps->ten_baihat      = $request->input('ten_baihat');
        $emps->loi_baihat      = $request->input('loi_baihat');
        $emps->hot_baihat      = $request->input('hot_baihat');
        $emps->link_baihat     = $request->input('link_baihat');
        $emps->mota_baihat     = $request->input('mota_baihat');
        $emps->ngaycapnhat     = $request->input('ngaycapnhat');
        $emps->solannghe       = $request->input('solannghe');
        $emps->solantai        = $request->input('solantai');
        $emps->playlist        = $request->input('playlist');
        $emps->solanyeuthich   = $request->input('solanyeuthich');
        $emps->id_theloainhac  = $request->input('id_theloainhac');
        $emps->id_album        = $request->input('id_album');
        $emps->id_casi         = $request->input('id_casi');
        $emps->id_nhacsi       = $request->input('id_nhacsi');

        $emps->save();

        return redirect('ql_baihat');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $this -> AuthLogin();
        $emps = emp_baihat::find($id);
        $emps->delete();

        return redirect('ql_baihat');
        
    } 

    
    
}
