<?php

namespace App\Http\Controllers;

use Session;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use App\emp_tln;
Session_start();
class quanlytln extends Controller
{
    public function AuthLogin(){
        $id_admin = Session::get('id_admin');
        if($id_admin){
            return Redirect::to('/dashboard');
        }else{
            return Redirect::to('/')->send();
        }
    }
    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
        $this -> AuthLogin();
         $emp1 = emp_tln::all();
         return view('ql_tln')->with('emp2',$emp1);
     }



    // HÀM INSERT 
    public function form_insert()
     {
        $this -> AuthLogin();
         return view('insert_tln');
     }
     public function store(Request $request)
     {
        $this -> AuthLogin();
         $this->validate($request,[
            'ten_theloainhac'=>'required',
            'hinh_theloainhac'=>'required',
            'mota_theloainhac'=>'required',
         ]);

         $emps= new emp_tln;
         $emps->ten_theloainhac = $request->input('ten_theloainhac');
         $emps->hinh_theloainhac = $request->input('hinh_theloainhac');
         $emps->mota_theloainhac = $request->input('mota_theloainhac');
         $emps->save();

         return redirect('ql_tln');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $this -> AuthLogin();
        $emps = emp_tln::find($id);
        return view('edit_tln')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this -> AuthLogin();
        $this->validate($request,[
           'ten_theloainhac'=>'required',
           'hinh_theloainhac'=>'required',
           'mota_theloainhac'=>'required',
        ]);

        $emps= emp_tln::find($id);

        $emps->ten_theloainhac = $request->input('ten_theloainhac');
        $emps->hinh_theloainhac = $request->input('hinh_theloainhac');
        $emps->mota_theloainhac = $request->input('mota_theloainhac');

        $emps->save();

        return redirect('ql_tln');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $this -> AuthLogin();
        $emps = emp_tln::find($id);
        $emps->delete();

        return redirect('ql_tln');
        
    } 
}
