<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emp;

class quanly extends Controller
{
    
    

    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
         $emp1 = emp::all();
         return view('ql_casi')->with('emp2',$emp1);
     }




    // HÀM INSERT 
    public function form_insert()
     {
         return view('insert_casi');
     }
     public function store(Request $request)
     {
         $this->validate($request,[
            'hoten_casi'=>'required',
            'hot_casi'=>'required',
            'hinh_casi'=>'required',
            'gioithieu_casi'=>'required',
         ]);

         $emps= new emp;
         $emps->hoten_casi = $request->input('hoten_casi');
         $emps->hot_casi = $request->input('hot_casi');
         $emps->hinh_casi = $request->input('hinh_casi');
         $emps->gioithieu_casi = $request->input('gioithieu_casi');
         $emps->save();

         return redirect('ql_casi');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $emps = emp::find($id);
        return view('edit_casi')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this->validate($request,[
           'hoten_casi'=>'required',
           'hot_casi'=>'required',
           'hinh_casi'=>'required',
           'gioithieu_casi'=>'required'
        ]);

        $emps= emp::find($id);

        $emps->hoten_casi = $request->input('hoten_casi');
        $emps->hot_casi = $request->input('hot_casi');
        $emps->hinh_casi = $request->input('hinh_casi');
        $emps->gioithieu_casi = $request->input('gioithieu_casi');

        $emps->save();

        return redirect('ql_casi');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $emps = emp::find($id);
        $emps->delete();

        return redirect('ql_casi');
        
    } 

    
    
}
