<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ListController extends Controller
{
    public function add_list_sing(){
        return view('admin.add_list_sing');
    }
    public function all_list_sing(){
        return view('admin.all_list_sing');
    }
}
