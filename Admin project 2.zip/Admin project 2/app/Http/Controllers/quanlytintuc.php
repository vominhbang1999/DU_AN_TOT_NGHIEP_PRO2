<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emp_tintuc;
use Session;
use App\Http\Requests;
use DB;
use Illuminate\Support\Facades\Redirect;
Session_start();
class quanlytintuc extends Controller
{
    
     // login
     public function AuthLogin(){
        $id_admin = Session::get('id_admin');
        if($id_admin){
            return Redirect::to('/dashboard');
        }else{
            return Redirect::to('/')->send();
        }
    }

    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
        $this -> AuthLogin();
         $emp1 = emp_tintuc::all();
         return view('admin.qltintuc.ql_tintuc')->with('emp2',$emp1);
     }




    // HÀM INSERT 
    public function form_insert()
     {
        $this -> AuthLogin();
         return view('admin.qltintuc.insert_tintuc');
     }
     public function store(Request $request)
     {
        $this -> AuthLogin();
         $this->validate($request,[
            'title_tintuc'=>'required',
            'tintuc_hot'=>'required',
            'noidung_tintuc'=>'required',
            'hinhanh_tintuc'=>'required',
            'luotxem'=>'required',
            'ngaydang_tintuc'=>'required'
         ]);

         $emps= new emp_tintuc;
         $emps->title_tintuc = $request->input('title_tintuc');
         $emps->tintuc_hot = $request->input('tintuc_hot');
         $emps->noidung_tintuc = $request->input('noidung_tintuc');
         $emps->hinhanh_tintuc = $request->input('hinhanh_tintuc');
         $emps->luotxem = $request->input('luotxem');
         $emps->ngaydang_tintuc = $request->input('ngaydang_tintuc');

         $emps->save();

         return redirect('ql_tintuc');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $this -> AuthLogin();
        $emps = emp_tintuc::find($id);
        return view('admin.qltintuc.edit_tintuc')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this -> AuthLogin();
        $this->validate($request,[
            'title_tintuc'=>'required',
            'tintuc_hot'=>'required',
            'noidung_tintuc'=>'required',
            'hinhanh_tintuc'=>'required',
            'luotxem'=>'required',
            'ngaydang_tintuc'=>'required'
        ]);

        $emps= emp_tintuc::find($id);

        $emps->title_tintuc = $request->input('title_tintuc');
        $emps->tintuc_hot = $request->input('tintuc_hot');
        $emps->noidung_tintuc = $request->input('noidung_tintuc');
        $emps->hinhanh_tintuc = $request->input('hinhanh_tintuc');
        $emps->luotxem = $request->input('luotxem');
        $emps->ngaydang_tintuc = $request->input('ngaydang_tintuc');

        $emps->save();

        return redirect('ql_tintuc');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $this -> AuthLogin();
        $emps = emp_tintuc::find($id);
        $emps->delete();

        return redirect('ql_tintuc');
        
    } 

    
    
}
