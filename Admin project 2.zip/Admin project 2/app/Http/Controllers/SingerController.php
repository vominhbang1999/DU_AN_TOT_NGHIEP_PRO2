<?php

// namespace App\Http\Controllers;

// use Illuminate\Support\Facades\Redirect;
// use Illuminate\Http\Request;
// use DB;
// use Session;
// use App\Http\Requests;
// session_start();

// class singerController extends Controller
// {
//     public function add_casi(){
//         return view('admin.add_casi');
//     }
//     public function all_casi(){
        
//         $all_casi = DB::table('casi')->get();
//         $manager_casi = view('admin.all_casi')->with('all_casi',$all_casi);
//         return view('admin_layout')->with('admin.all_casi', $manager_casi);
//     }
//     public function save_casi(Request $request){
        
//         $data = array();
//         $data['hoten_casi'] = $request->hoten_casi;
//         $data['hot_casi'] = $request->hot_casi;
//         $data['hinh_casi'] = $request->hinh_casi;
//         $data['gioithieu_casi'] = $request->gioithieu_casi;

//         DB::table('casi')->insert($data);
//         Session::put('message','Thêm ca sĩ thành công');
//         return Redirect::to('add-casi');
//     }
//     public function edit_casi($id_casi_singer){
        
//         $edit_casi = DB::table('casi')->where('id_casi',$id_casi_singer)->get();
//         $manager_casi = view('admin.edit_casi')->with('edit_casi',$edit_casi);
//         return view('admin_layout')->with('admin.edit_casi', $manager_casi);
//     }
//     public function update_casi(Request $request, $id_casi_singer){
        
//         $data = array();
//         $data['hoten_casi'] = $request->hoten_casi;
//         $data['hot_casi'] = $request->hot_casi;
//         $data['hinh_casi'] = $request->hinh_casi;
//         $data['gioithieu_casi'] = $request->gioithieu_casi;

//         DB::table('casi')->where('id_casi',$id_casi_singer)->update($data);
//         Session::put('message','Cập nhật ca sĩ thành công');
//         return Redirect::to('all-casi');
//     }

//}
