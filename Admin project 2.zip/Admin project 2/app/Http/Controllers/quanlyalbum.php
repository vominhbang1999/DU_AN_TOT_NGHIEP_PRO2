<?php

namespace App\Http\Controllers;

use Session;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use App\emp_album;
Session_start();
class quanlyalbum extends Controller
{
    public function AuthLogin(){
        $id_admin = Session::get('id_admin');
        if($id_admin){
            return Redirect::to('/dashboard');
        }else{
            return Redirect::to('/')->send();
        }
    }
    // HÀM HIỂN THỊ DỮ LIỆU
    public function index()
     {
        $this -> AuthLogin();
         $emp1 = emp_album::all();
         return view('ql_album')->with('emp2',$emp1);
     }



    // HÀM INSERT 
    public function form_insert()
     {
        $this -> AuthLogin();
         return view('insert_album');
     }
     public function store(Request $request)
     {
        $this -> AuthLogin();
         $this->validate($request,[
            'ten_album'=>'required',
            'hot_album'=>'required',
            'hinh_album'=>'required',
            'mota_album'=>'required',
            'ngaycapnhat_album'=>'required',
         ]);

         $emps= new emp_album;
         $emps->ten_album = $request->input('ten_album');
         $emps->hot_album = $request->input('hot_album');
         $emps->hinh_album = $request->input('hinh_album');
         $emps->mota_album = $request->input('mota_album');
         $emps->ngaycapnhat_album = $request->input('ngaycapnhat_album');
         $emps->save();

         return redirect('ql_album');

     }



    //  HÀM EDIT



    public function form_edit($id) 
    {
        $this -> AuthLogin();
        $emps = emp_album::find($id);
        return view('edit_album')->with('emp',$emps);
    } 

    public function update(Request $request, $id)
    {
        $this -> AuthLogin();
        $this->validate($request,[
           'ten_album'=>'required',
           'hot_album'=>'required',
           'hinh_album'=>'required',
           'mota_album'=>'required',
           'ngaycapnhat_album'=>'required'
        ]);

        $emps= emp_album::find($id);

        $emps->ten_album = $request->input('ten_album');
        $emps->hot_album = $request->input('hot_album');
        $emps->hinh_album = $request->input('hinh_album');
        $emps->mota_album = $request->input('mota_album');
        $emps->ngaycapnhat_album = $request->input('ngaycapnhat_album');

        $emps->save();

        return redirect('ql_album');


    }
     


    // HÀM DELETE 
    
    public function delete($id) 
    {
        $this -> AuthLogin();
        $emps = emp_album::find($id);
        $emps->delete();

        return redirect('ql_album');
        
    } 
}
