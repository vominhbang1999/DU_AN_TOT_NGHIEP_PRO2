<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_tln extends Model
{
    protected $primaryKey='id_theloainhac';
        protected $table='theloainhac';
        protected $filltable=array('ten_theloainhac','hinh_theloainhac','mota_theloainhac');
        
}