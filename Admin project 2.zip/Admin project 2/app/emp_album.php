<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_album extends Model
{
    protected $primaryKey='id_album';
        protected $table='album';
        protected $filltable=array('ten_album','hot_album','hinh_album','mota_album','ngaycapnhat_album');
        
}