<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_nhacsi extends Model
{
    protected $primaryKey='id_nhacsi';
    protected $table='nhacsi';
    protected $filltable=array('title_nhacsi','nhacsi_hot','noidung_nhacsi','hinhanh_nhacsi','ngaydang_nhacsi','luotxem');
}

