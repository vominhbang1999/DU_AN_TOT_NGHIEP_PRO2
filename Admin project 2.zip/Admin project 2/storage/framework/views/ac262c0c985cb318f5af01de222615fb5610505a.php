<?php $__env->startSection('admin.admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách Nhạc sĩ
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td >Id_nhacsi</td>
            <td>Tiêu đề tin</td>
            <td>Hot</td>
            <td>Nội dung</td>
            <td>Hình</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $emp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><span class="text-ellipsis"><?php echo e($emp3->id_nhacsi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hoten_nhacsi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hot_nhacsi); ?> ★</span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hinh_nhacsi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->gioithieu_nhacsi); ?></span></td>

            <td>
                <a href="<?php echo e(URL::to('/edit_nhacsi/'.$emp3->id_nhacsi)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a onclick="return confirm('Bạn có muốn xóa không?')" href="<?php echo e(URL::to('/delete_nhacsi/'.$emp3->id_nhacsi)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2\resources\views/admin/qlnhacsi/ql_nhacsi.blade.php ENDPATH**/ ?>