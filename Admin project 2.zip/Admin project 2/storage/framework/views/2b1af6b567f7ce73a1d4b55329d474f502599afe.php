<?php $__env->startSection('admin.admin_content'); ?>
<h3>Chào mừng đến với Admin</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>