<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật Album bài hát
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_album/<?php echo e($emp->id_album); ?>' method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên album</label>
                            <input type="text" class="form-control" name='ten_album' value=<?php echo e($emp->hoten_album); ?> >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hot <?php echo e($emp->hot_album); ?> ★</label>
                            <select class="form-control"  name='hot_album' id="exampleFormControlInput1" >
                                <option value="1">1 ★</option>
                                <option value="2">2 ★</option>
                                <option value="3">3 ★</option>
                                <option value="4">4 ★</option>
                                <option value="5">5 ★</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputFile">Hình album</label>
                            <input type="file" name='hinh_album' value=<?php echo e($emp->hinh_album); ?> id="exampleInputFile">
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Mô tả</label>
                            <div >
                                <textarea class="form-control" id="ccomment" value=<?php echo e($emp->mota_album); ?> name='mota_album' required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group ">
                            <label for="comment">Ngày cập nhật</label>
                            <div >
                                <input type="date" class="form-control" id="comment" name='ngaycapnhat_album' value=<?php echo e($emp->ngaycapnhat_album); ?>  />
                            </div>
                        </div>

                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2 2\resources\views/admin/qlalbum/edit_album.blade.php ENDPATH**/ ?>