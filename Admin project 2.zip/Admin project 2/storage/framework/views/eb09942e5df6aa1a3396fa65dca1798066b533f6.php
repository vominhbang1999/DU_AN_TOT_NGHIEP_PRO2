<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm tintuc
            </header>
            <div class="panel-body">1
                <div class="position-center">
                    <form role="form" action="store_tintuc" method="get">
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên tintuc</label>
                            <input type="text" class="form-control" name='title_tintuc' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hot</label>
                            <select class="form-control"  name='tintuc_hot' id="exampleFormControlInput1" >
                                <option value="1">1 ★</option>
                                <option value="2">2 ★</option>
                                <option value="3">3 ★</option>
                                <option value="4">4 ★</option>
                                <option value="5">5 ★</option>
                            </select>
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Nội dung</label>
                            <div >
                                <textarea class="form-control" id="ccomment"  name='noidung_tintuc' required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputFile">Hình </label>
                            <input type="file" name='hinhanh_tintuc' id="exampleInputFile">
                        </div>
                        
                        <div class="form-group ">
                            <label for="ccomment">Ngày đăng tin</label>
                            <div >
                                <input type="date" class="form-control" id="ccomment" name='ngaydang_tintuc'  />
                            </div>
                        </div>
                        <div class="form-group ">
                            <label for="omment">Lượt xem</label>
                            <div >
                                <input type="text" class="form-control" id="omment"   name='luotxem' >  
                            </div>
                        </div>

                        <input type="submit" name="save" class="btn btn-info" value='INSERT'/>
                        
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2 2\resources\views/admin/qltintuc/insert_tintuc.blade.php ENDPATH**/ ?>