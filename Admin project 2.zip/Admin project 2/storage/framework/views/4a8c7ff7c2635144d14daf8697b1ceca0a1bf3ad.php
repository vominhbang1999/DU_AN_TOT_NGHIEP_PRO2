<?php $__env->startSection('admin.admin_content'); ?>
<h1 class="text-center" style="color: white;"> Trang quản lý Music website </h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2 2\resources\views/admin/admin_index.blade.php ENDPATH**/ ?>