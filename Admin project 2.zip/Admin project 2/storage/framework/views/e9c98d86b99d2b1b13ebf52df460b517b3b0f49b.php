<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật thể loại nhạc
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_tln/<?php echo e($emp->id_theloainhac); ?>' method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên thể loại nhạc</label>
                            <input type="text" class="form-control" name='ten_theloainhac' value=<?php echo e($emp->ten_theloainhac); ?> id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputFile">Hình thể loại nhạc</label>
                            <input type="file" name='hinh_theloainhac' value=<?php echo e($emp->hinh_theloainhac); ?> id="exampleInputFile">
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Mô tả thể loại nhạc</label>
                            <div >
                                <textarea class="form-control" id="ccomment" value=<?php echo e($emp->mota_theloainhac); ?> name='mota_theloainhac' required=""></textarea>
                            </div>
                        </div>                 
                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Admin project 2\resources\views/edit_tln.blade.php ENDPATH**/ ?>