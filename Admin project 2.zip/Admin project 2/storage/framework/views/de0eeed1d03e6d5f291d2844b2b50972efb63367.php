<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm Bài hát
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action="store_baihat" method="get">
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên bài hát</label>
                            <input type="text" class="form-control" name='ten_baihat' id="exampleInputPassword1" >
                        </div>
                        <div class="form-group ">
                            <label for="omment">Lời bài hát</label>
                            <div >
                                <textarea class="form-control" id="omment" name='loi_baihat' required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hot</label>
                            <select class="form-control"  name='hot_baihat' id="exampleFormControlInput1" >
                                <option value="1">1 ★</option>
                                <option value="2">2 ★</option>
                                <option value="3">3 ★</option>
                                <option value="4">4 ★</option>
                                <option value="5">5 ★</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">link bài hát</label>
                            <input type="text" class="form-control" name='link_baihat' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Giới thiệu</label>
                            <div >
                                <textarea class="form-control" id="ccomment" name='mota_baihat' required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Ngày cập nhật</label>
                            <input type="date" class="form-control" name='ngaycapnhat' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần nghe</label>
                            <input type="number" class="form-control" name='solannghe' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần tải</label>
                            <input type="number" class="form-control" name='solantai' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Play list</label>
                            <select class="form-control"  name='playlist' id="exampleFormControlInput1" >
                                <option value="1">Yêu thích</option>
                                <option value="2">Nghe nhiều</option>
                                <option value="3">Cá nhân</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần yêu thích</label>
                            <input type="number" class="form-control" name='solanyeuthich' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id thể loai nhạc</label>
                            <input type="number" class="form-control" name='id_theloainhac' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id album</label>
                            <input type="number" class="form-control" name='id_album' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id ca sĩ</label>
                            <input type="number" class="form-control" name='id_casi' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id nhạc sĩ</label>
                            <input type="number" class="form-control" name='id_nhacsi' id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        
                        

                        <input type="submit" name="save" class="btn btn-info" value='INSERT'/>
                        
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2\resources\views/admin/qlbaihat/insert_baihat.blade.php ENDPATH**/ ?>