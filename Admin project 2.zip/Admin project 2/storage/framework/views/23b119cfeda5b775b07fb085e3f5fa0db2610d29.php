<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật Album bài hát
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_baihat/<?php echo e($emp->id_baihat); ?>' method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                            <label for="exampleInputPassword1">Tên bài hát</label>
                            <input type="text" class="form-control" name='ten_baihat' id="exampleInputPassword1" value=<?php echo e($emp->ten_baihat); ?> >
                        </div>
                        <div class="form-group ">
                            <label for="omment">Lời bài hát</label>
                            <div >
                                <textarea class="form-control" id="omment" name='loi_baihat' id="exampleInputPassword1" value=<?php echo e($emp->loi_baihat); ?> required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hot <?php echo e($emp->hot_baihat); ?> ★</label>
                            <select class="form-control"  name='hot_baihat'  >
                                <option value="1">1 ★</option>
                                <option value="2">2 ★</option>
                                <option value="3">3 ★</option>
                                <option value="4">4 ★</option>
                                <option value="5">5 ★</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">link bài hát</label>
                            <input type="text" class="form-control" name='link_baihat' id="exampleInputPassword1" value=<?php echo e($emp->link_baihat); ?> >
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Giới thiệu</label>
                            <div >
                                <textarea class="form-control" id="ccomment" name='mota_baihat' id="exampleInputPassword1" value=<?php echo e($emp->mota_baihat); ?> required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Ngày cập nhật</label>
                            <input type="date" class="form-control" name='ngaycapnhat' id="exampleInputPassword1" value=<?php echo e($emp->ngaycapnhat); ?>>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần nghe</label>
                            <input type="number" class="form-control" name='solannghe' id="exampleInputPassword1" value=<?php echo e($emp->solannghe); ?>>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần tải</label>
                            <input type="number" class="form-control" name='solantai' id="exampleInputPassword1" value=<?php echo e($emp->solantai); ?> >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Play list</label>
                            <select class="form-control"  name='playlist' id="exampleInputPassword1" value=<?php echo e($emp->playlist); ?> >
                                <option value="Yêu thích">Yêu thích</option>
                                <option value="Nghe nhiều">Nghe nhiều</option>
                                <option value="Cá nhân">Cá nhân</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần yêu thích</label>
                            <input type="number" class="form-control" name='solanyeuthich' id="exampleInputPassword1" value=<?php echo e($emp->solanyeuthich); ?> >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id thể loai nhạc</label>
                            <input type="number" class="form-control" name='id_theloainhac' id="exampleInputPassword1" value=<?php echo e($emp->id_theloainhac); ?>  >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id album</label>
                            <input type="number" class="form-control" name='id_album' id="exampleInputPassword1" value=<?php echo e($emp->id_album); ?> >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id ca sĩ</label>
                            <input type="number" class="form-control" name='id_casi' id="exampleInputPassword1" value=<?php echo e($emp->id_casi); ?> >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">id nhạc sĩ</label>
                            <input type="number" class="form-control" name='id_nhacsi' id="exampleInputPassword1" value=<?php echo e($emp->id_nhacsi); ?> >
                        </div>   
                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2\resources\views/admin/qlbaihat/edit_baihat.blade.php ENDPATH**/ ?>