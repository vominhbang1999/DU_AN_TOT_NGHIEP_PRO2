<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách ca sĩ
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td >Id_casi</td>
            <td>Tên ca sĩ</td>
            <td>Hot</td>
            <td>Hình</td>
            <td>Giới thiệu</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $emp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><span class="text-ellipsis"><?php echo e($emp3->id_casi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hoten_casi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hot_casi); ?> ★</span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hinh_casi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->gioithieu_casi); ?></span></td>
            <td>
                <a href="<?php echo e(URL::to('/edit_casi/'.$emp3->id_casi)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a onclick="return confirm('Are you sure to delete?')" href="<?php echo e(URL::to('/delete_casi/'.$emp3->id_casi)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Admin project 2\resources\views/ql_casi.blade.php ENDPATH**/ ?>