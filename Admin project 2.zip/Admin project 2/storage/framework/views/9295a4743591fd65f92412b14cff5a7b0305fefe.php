<?php $__env->startSection('admin_content'); ?>
<h3>Chào mừng đến với Admin</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Admin project 2\resources\views/dashboard.blade.php ENDPATH**/ ?>