<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách thể loại nhạc
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td >Id_theloainhac</td>
            <td>Tên thể loại nhạc</td>
            <td>Hình</td>
            <td>Mô tả</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $emp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><span class="text-ellipsis"><?php echo e($emp3->id_theloainhac); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->ten_theloainhac); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->hinh_theloainhac); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->mota_theloainhac); ?></span></td>
            <td>
                <a href="<?php echo e(URL::to('/edit_tln/'.$emp3->id_theloainhac)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a href="<?php echo e(URL::to('/delete_tln/'.$emp3->id_theloainhac)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Admin project 2\resources\views/ql_tln.blade.php ENDPATH**/ ?>