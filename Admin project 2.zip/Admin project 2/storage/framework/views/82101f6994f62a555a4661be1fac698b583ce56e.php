<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật Tin tức
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_tintuc/<?php echo e($emp->id_tintuc); ?>' method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Tiêu đề tin</label>
                            <input type="text" class="form-control" name='title_tintuc' value=<?php echo e($emp->title_tintuc); ?> >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hot <?php echo e($emp->hot_tintuc); ?> ★</label>
                            <select class="form-control"  name='tintuc_hot' id="exampleFormControlInput1" >
                                <option value="1">1 ★</option>
                                <option value="2">2 ★</option>
                                <option value="3">3 ★</option>
                                <option value="4">4 ★</option>
                                <option value="5">5 ★</option>
                            </select>
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Nội dung</label>
                            <div >
                                <textarea class="form-control" id="ccomment" value=<?php echo e($emp->noidung_tintuc); ?> name='noidung_tintuc' required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputFile">Hình</label>
                            <input type="file" name='hinhanh_tintuc' value=<?php echo e($emp->hinhanh_tintuc); ?> id="exampleInputFile">
                        </div>
                        <div class="form-group ">
                            <label for="comment">Ngày cập nhật</label>
                            <div >
                                <input type="date" class="form-control" id="comment" name='ngaydang_tintuc' value=<?php echo e($emp->ngaydang_tintuc); ?>  />
                            </div>
                        </div>
                        <div class="form-group ">
                            <label for="comment">Lượt xem</label>
                            <div >
                                <input type="number" class="form-control" id="comment" name='luotxem' value=<?php echo e($emp->luotxem); ?>  />
                            </div>
                        </div>

                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2\resources\views/admin/qltintuc/edit_tintuc.blade.php ENDPATH**/ ?>