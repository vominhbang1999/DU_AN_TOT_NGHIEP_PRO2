<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm danh mục bài hát
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form">
                        <div class="form-group">
                            <label for="exampleInputEmail1">ID bài hát</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" disabled>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên bài hát</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Nhập tên bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hot bài hát</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" >
                        </div>
                        <div class="form-group ">
                            <label for="ccomment">Lời bài hát</label>
                            <div >
                                <textarea class="form-control " id="ccomment" name="comment" required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Link bài hát</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Link bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mô tả bài hát</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Nhập mô tả bài hát">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Ngày cập nhật</label>
                            <input type="date" class="form-control" id="exampleInputPassword1" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần nghe</label>
                            <input type="number" class="form-control" id="exampleInputPassword1" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần tải</label>
                            <input type="number" class="form-control" id="exampleInputPassword1" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Playlist</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Playlist">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Số lần yêu thích</label>
                            <input type="number" class="form-control" id="exampleInputPassword1" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Id thể loại nhạc</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Id thể loại nhạc" disabled>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Id album</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Id album" disabled>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Id ca sĩ</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Id ca sĩ" disabled>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Id nhạc sĩ</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Id nhạc sĩ" disabled>
                        </div>
                        <button type="submit" class="btn btn-info">Thêm mới</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DUAN2_LARAVEL\resources\views/admin/add_category_sing.blade.php ENDPATH**/ ?>