<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật Tin tức
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action='../save_playlist/<?php echo e($emp->id_playlist); ?>' method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group ">
                            <label for="comment">Lượt xem</label>
                            <div >
                                <input type="number" class="form-control" id="comment" name='id_baihat' value=<?php echo e($emp->id_baihat); ?>  />
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Tiêu đề tin</label>
                            <input type="text" class="form-control" name='ten_playlist' value=<?php echo e($emp->ten_playlist); ?> >
                        </div>
    
                        
                        <div class="form-group">
                            <label for="exampleInputFile">Hình</label>
                            <input type="file" name='hinhanh_playlist' value=<?php echo e($emp->hinhanh_playlist); ?> id="exampleInputFile">
                        </div>
                        
                        <div class="form-group ">
                            <label for="ccomment">Nội dung</label>
                            <div >
                                <textarea class="form-control" id="ccomment" value=<?php echo e($emp->mota_playlist); ?> name='mota_playlist' required=""></textarea>
                            </div>
                        </div>

                        <button type="submit" name="save" class="btn btn-info">Cập nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebServer\Admin project 2\resources\views/admin/qlplaylist/edit_playlist.blade.php ENDPATH**/ ?>