$('.duma').click(function (e) { 
    e.preventDefault();
    $('.mobile').toggleClass('heightauto');
    $(this).toggleClass('xoay180');
   
    
    
});

$(document).ready(function () {
    if ($(t).text("rutgon")) {
        
    } else {
        
    }
});

$('.duma2').click(function (e) { 
    e.preventDefault();
    $('.mobile2').toggleClass('heightauto');
    $(this).toggleClass('xoay180');
    
});
$('.duma3').click(function (e) { 
    e.preventDefault();
    $('.mobile3').toggleClass('heightauto');
    $(this).toggleClass('xoay180');
    
});
$('.duma4').click(function (e) { 
    e.preventDefault();
    $('.mobile4').toggleClass('heightauto');
    $(this).toggleClass('xoay180');
    
});
$('.duma5').click(function (e) { 
    e.preventDefault();
    $('.mobile5').toggleClass('heightauto');
    $(this).toggleClass('xoay180');
    
});





 