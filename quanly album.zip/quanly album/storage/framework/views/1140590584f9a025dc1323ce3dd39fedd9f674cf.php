<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Quản lý album</title>
</head>
<body>
    <div class="container">
        <div class="row mt-5">

            <div class="col-md-10">
                <div class="row btn btn-light" style="width:100%; height:auto">
                    <p>Quản lý album</p>
                </div>

                <div class="row">
                <table class="table table-light">
                    <tr>
                        <td>id_album</td>
                        <td>Tên album</td>
                        <td>Hot</td>
                        <td>Hình</td>
                        <td>Mô tả</td>
                        <td>Ngày cập nhật</td>
                        <td>Sửa</td>
                        <td>Xóa</td>
                    </tr>
                    <?php $__currentLoopData = $emp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                            <td><?php echo e($emp3->id_album); ?></td>
                        
                            <td><?php echo e($emp3->ten_album); ?></td>
                       
                            <td><?php echo e($emp3->hot_album); ?></td>

                            <td><?php echo e($emp3->hinh_album); ?></td>

                            <td><?php echo e($emp3->mota_album); ?></td>
                            
                            <td><?php echo e($emp3->ngaycapnhat_album); ?></td>
                        
                            <td><a href="edit/<?php echo e($emp3->id_album); ?>" class="btn btn-success">Sửa</a></td>
                            <td><a href="delete/<?php echo e($emp3->id_album); ?>" class="btn btn-success">Xóa</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>


                </div>
                
            </div>

        </div>
    </div>
</body>
</html><?php /**PATH E:\WebServer\THEM_XOA_SUA album\resources\views/dulieu.blade.php ENDPATH**/ ?>