    <footer>
        <div class="container">
            <div class="row ">
                <div class="col-lg-6">
                    <div class="row">
                        <div class=" col-6 col-lg-3">
                            <div class="wapper-ft">
                                <ul>
                                    <li class="top-list">
                                        <a href="#">
                                            Thông tin
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Gioi thiệu
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Điều khoản sử dụng
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Quyền riêng tư
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <!-- end col -->
                        <div class="col-6 col-lg-3">
                            <div class="wapper-ft">
                                <ul>
                                    <li class="top-list">
                                        <a href="#">
                                            Bài hát
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            ALbum
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Hotlist
                                        </a>
                                    </li>



                                </ul>
                            </div>
                        </div>
                        <!-- end col -->
                        <div class="col-6 col-lg-2">
                            <div class="wapper-ft">
                                <ul>
                                    <li class="top-list">
                                        <a href="#" class="text-uppercase">
                                            bxh
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="text-uppercase">
                                            mv
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Ngệ sĩ
                                        </a>
                                    </li>



                                </ul>
                            </div>
                        </div>
                        <!-- end col -->
                        <div class="col-6 col-lg-4">
                            <div class="wapper-ft">
                                <ul>
                                    <li class="top-list">
                                        <a href="team.html">
                                            Kết nối với team 
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <figure></figure>
                                            <img src="{{URL::asset('img/icon-fb-bottom.png')}}" alt="" class="img-fluid">
                                            </figure>
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="wapper-ft">
                                <ul>
                                    <li class="top-list">
                                        <a href="#" class="">
                                            Tải ứng dụng
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="">
                                            Dịch vụ nhac.vn đã có ứng dụng cho
                                        </a>
                                    </li>
                                    <li class="mobile-mb">
                                        <a href="#">
                                            Mobile, Smart TV
                                        </a>
                                    </li>
                                    <li class="d-flex">
                                        <figure>
                                            <img src="{{URL::asset('img/icon-code-bottom.png')}}" alt="">
                                        </figure>
                                        <div class="list-dr">

                                            <button class="btn">
                                                <img src="{{URL::asset('img/btn-down-iphone (1).png')}}" alt="">
                                                Tải cho i phone
                                            </button>
                                            <button class="btn">
                                                <img src="{{URL::asset('img/btn-down-android.png')}}" alt="">
                                                Tải cho Androi
                                            </button>
                                        </div>
                                    </li>



                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="wapper-ft">
                                <ul>
                                    <li class="top-list">
                                        Từ khóa nổi bật
                                    </li>
                                    <li>
                                        Yêu Em Dại Khờ, Những Bài Hát Hay Nhất
                                    </li>
                                    <li>
                                        Mùa xuân, Tình nhân ơi , Anh ỡ đâu
                                    </li>
                                    <li>
                                        Anh chưa từng
                                    </li>
                                    <li class="top-list cx">
                                        liên kết
                                    </li>
                                    <li>
                                        <a href="https://hopamchuan.com/"> Hopamchuan.com </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end -->
            <div class="row">
                <div class="col-lg-2">
                    <figure>
                        <img src="{{URL::asset('img/bottom-logo.png')}}" alt="" class="img-fluid">
                    </figure>
                </div>
                <div class="col-lg-8">
                    <figcaption>
                        <span>
                            Cơ quan chủ quản Công ty Cổ phần Bạch Minh - Địa chỉ: P804, Tòa nhà VET, 98 Hoàng Quốc Việt,
                            Hà Nội
                        </span>
                        <span>
                            Email: Nhac@vega.com.vn Tel: 024 37554190 - Người chịu trách nhiệm nội dung: Ông Lê Hữu Toàn
                        </span>
                        <span>
                            Giấy phép MXH số 311/GP-BTTTT do Bộ Thông Tin và Truyền thông cấp ngày 04/07/2017
                        </span>
                    </figcaption>

                    <div class="yearr" style="font-size: 14px">
                        © 2015 Vega Corporation
                    </div>
                </div>
                <div class="col-lg-2 hidden-mobile">
                    <figure class="cv">
                        <img src="{{URL::asset('img/dathongbao.png')}}" alt="" class="img-fluid">
                    </figure>
                </div>
            </div>
        </div>
        <!-- eeeeeeeeeeeeeee -->



        <!-- eeeeeeeeeeeeeee -->

        
        <!-- end -->
        <!-- bactotop -->
        <section class="backtotop">
            <i class="fas fa-chevron-up"></i>
            <img src="{{URL::asset('img/tooo.png')}}" alt="" style="width: 100%; height:100%; border-radius: 50%;">
        </section>
    </footer>
</body>

<script src="{{URL::asset('js/jquery-2.2.4.js')}}" ></script>
<script src="{{URL::asset('js/jquery-migrate-1.2.1.min.js')}}"></script>
<script src="{{URL::asset('slick/slick.min.js')}}"></script>

<!-- OWL CAROUSEL  -->
<script src="{{URL::asset('js/owl.carousel.js')}}"></script>
<!-- botttrap -->
<script src="{{URL::asset('js/bootstrap.min.js')}}"></script>
<script src="{{URL::asset('js/popper.min.js')}}"></script>
<!-- plyr -->
<!-- wow js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
<!-- MENU JS -->
<script src="{{URL::asset('js/menu.js')}}"></script>
<!-- wow js -->

<script src="{{URL::asset('js/main.js')}}"></script>

<script src="{{URL::asset('js/core.js')}}"></script>

<script src="{{URL::asset('js/personaluse.js')}}" ></script>

<!-- VIDEO JS -->
<script src="{{URL::asset('js/plyr.js')}}" ></script>
<!-- VIDEO JS -->



</html>