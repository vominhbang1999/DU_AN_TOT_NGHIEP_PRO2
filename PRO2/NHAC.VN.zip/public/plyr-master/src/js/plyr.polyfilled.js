// ==========================================================================
// Plyr Polyfilled Build
// plyr.js v3.5.6
// https://github.com/sampotts/plyr
// License: The MIT License (MIT)
// ==========================================================================

import 'custom-event-polyfill';
import 'url-polyfill';

import Plyr from './plyr';

export default Plyr;
