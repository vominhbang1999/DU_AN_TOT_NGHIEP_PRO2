<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use DB;
use Session;
use App\emp_baihat;
use App\emp_users;
use App\emp_blbaihat;
use App\emp_bltintuc;
use App\Http\Requests;
use Auth;
session_start();

class AdminController extends Controller
{
    //login
    public function login(Request $request){

         $this->validate($request,
            [
                'name'=>'required', 
                'password'=>'required|min:8'
            ],
            [
                'name.required'=>'Vui lòng nhập username',
                'password.required'=>'Vui lòng nhập mật khẩu',
                'password.min'=>'Mật khẩu ít nhất 8 kí tự',
            ]
        );

        
        $credentials = array('name'=>$request->name,'password'=>$request->password,'admin'=>'1');

        if(Auth::attempt($credentials)){

            $baihat_count = emp_baihat::count();
            $users_count = emp_users::count();
            $binhluanbaihat_count = emp_blbaihat::count();
            $binhluantintuc_count = emp_bltintuc::count();
            return view('admin.dashboard', compact('baihat_count','users_count','binhluanbaihat_count','binhluantintuc_count'));
        }
        else{

            return redirect()->back()->with(['flag'=>'danger','message'=>'Đăng nhập không thành công']);

        }

    
    }
    // public function login(){


    //     $id_admin = Session::get('id_admin');
    //     if($id_admin){
    //         return Redirect::to('/dashboard');
    //     }else{
    //         return Redirect::to('/admin')->send();
    //     }
    // } 

    public function index(){
    
        return view('admin.admin_login');
    }

    public function show_dashboard(){
        $baihat_count = emp_baihat::count();
        $users_count = emp_users::count();
        $binhluanbaihat_count = emp_blbaihat::count();
        $binhluantintuc_count = emp_bltintuc::count();
        return view('admin.dashboard', compact('baihat_count','users_count','binhluanbaihat_count','binhluantintuc_count'));
    }
    public function dashboard(Request $request){
        
        $email_admin = $request->input('email_admin');
		$password_admin = $request->input('password_admin');

        $result = DB::table('admin')->where('email_admin',$email_admin)->where('password_admin',$password_admin)->first();
        if($result){
            Session::put('name_admin',$result->name_admin);
            Session::put('id_admin',$result->id_admin);
            return Redirect::to('dashboard');
        }else{
            Session::put('message','Email hoặc password không đúng');
            return Redirect::to('/admin');
        }
    }
    public function logout(){
        
        Session::put('name_admin',null);
        Session::put('id_admin',null);
        return Redirect::to('/admin');
    }
}

