<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <div class="bgcasi">
            <div class="container">
                <img src="<?php echo e(URL::asset('img/vip/logo.png')); ?>" />
                <h1>Tạo tài khoản thêm nghệ sĩ yêu thích</h1>
                <div class="link">
                    <a href="#">Đăng ký</a>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="title row">
                <nav class="navbar navbar-expand-lg">
                    <h1>
                        <a class="" href="#">Nghệ sĩ</a>
                    </h1>
                    <div class="menu collapse navbar-collapse">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Nổi bật</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Mới</a>
                          </li>
                        </ul>
                    </div>
                </nav>
                <!-- ./ link -->
                <div class="choose">
                    <form action="sapxepnghesi" method="post" class="cangiua" >
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group">
                              <select class="form-control form-control-lg"  required  name="khuvuccasi">
                                <option value="1">- Chọn quốc gia</option>
                                <option value="1">- Việt Nam</option>
                                <option value="2">- Âu Mĩ</option>
                                <option value="3">- Châu á</option>
                              </select>
                          </div>
                        <div class="form-group">
                              <select class="form-control form-control-lg"  required  name="thutuaz">
                                <option value="A">- Hiển thị theo -</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                                <option value="F">F</option>
                                <option value="G">G</option>
                                <option value="H">H</option>
                                <option value="I">I</option>
                                <option value="J">J</option>
                                <option value="K">K</option>
                                <option value="L">L</option>
                                <option value="M">M</option>
                                <option value="N">N</option>
                                <option value="O">O</option>
                                <option value="P">P</option>
                                <option value="Q">Q</option>
                                <option value="R">R</option>
                                <option value="S">S</option>
                                <option value="T">T</option>
                                <option value="U">U</option>
                                <option value="V">V</option>
                                <option value="W">W</option>
                                <option value="X">X</option>
                                <option value="Y">Y</option>
                                <option value="Z">Z</option>
                                </select>
                          </div>
                        <div class="form-group">
                            <input type="submit" name="submit" value="Tìm">
                        </div>

                    </form>
                </div>
                <!-- ./ select -->
            </div>
            <!-- ./title -->



            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                  <div class="list row">
                        <?php $__currentLoopData = $loai_casi_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai_casi3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-sm-4 col-lg-3 element">
                            <div class="card wow bounceInUp">
                                <div class="img">
                                    <a href="<?php echo e(route('detailcasi',$loai_casi3->id)); ?>"><img src="<?php echo e(URL::asset($loai_casi3->avatar_casi)); ?>" class="img-fluid" />
                                        <div class="overlay">
                                            <i class="iconplay fa fa-play-circle-o"></i>
                                            <i class="iconheart fa fa-heart-o"></i>
                                        </div>
                                    </a>
                                </div>
                                <div class="card-body text-center">
                                    <a href="#"><h5 class="card-title"><?php echo e($loai_casi3->hoten_casi); ?></h5></a>
                                    <p class="card-text"><?php echo e($loai_casi3->yeuthich); ?>  lượt thích</p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                     <div class="pages">
                        <ul class="nav justify-content-center">
                            <li class="">
                                <?php echo e($loai_casi_hot->links()); ?>

                            </li>
                        </ul>
                    </div>
              </div>
              <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                  
                  <div class="list row">
                    <?php $__currentLoopData = $thang_casi_moi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai_casi3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-sm-4 col-lg-3 element">
                        <div class="card wow bounceInUp">
                            <div class="img">
                                <a href="<?php echo e(route('detailcasi',$loai_casi3->id)); ?>"><img src='<?php echo e(URL::asset($loai_casi3->avatar_casi)); ?>' class="img-fluid" />
                                    <div class="overlay">
                                        <i class="iconplay fa fa-play-circle-o"></i>
                                        <i class="iconheart fa fa-heart-o"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="card-body text-center">
                                <a href="#"><h5 class="card-title"><?php echo e($loai_casi3->hoten_casi); ?></h5></a>
                                <p class="card-text"><?php echo e($loai_casi3->yeuthich); ?> lượt thích</p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                     <div class="pages">
                        <ul class="nav justify-content-center">
                            <li class="">
                                <?php echo e($thang_casi_moi->links()); ?>

                            </li>
                        </ul>
                    </div>
              </div>
            </div>
            
            <!-- ./ list -->
            <hr>
           
            <!-- ./ pages -->
        </div>
        <!-- ./ container -->
    </main>

<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/casi.blade.php ENDPATH**/ ?>