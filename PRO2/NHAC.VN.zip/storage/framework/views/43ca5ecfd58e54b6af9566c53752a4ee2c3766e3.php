<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- BEGIN MAIN -->
    <main>
        <section class="details">
            <div class="container">

                <div class="row">
                        <div class="col-12 col-lg-9 cd">
                                <div class="detailsong">
                                    <h1 class="name-detail">
            
                                        Nơi Này Có Anh -
                                        <span class="artist">
                                            <a href="">
                                                    Sơn Tùng MTP 
                                            </a>
                                           
                                        </span>
                                    </h1>
                                </div>
            
                                <ul class="detail-info">
                                    <li>
                                        <p class="song-detail">
                                            <span class="label">
                                                Nhạc sĩ :
                                            </span>
                                            <span class="val">
                                                Sơn Tùng MTP
                                            </span>
                                        </p>
                                    </li>
                                    <li>
                                        <p class="song-detail">
                                            <span class="label">
                                                Thể Loại:
                                            </span>
                                            <span class="val">
                                                Nhạc trẻ
                                            </span>
                                        </p>
                                    </li>
                                </ul>
                                <div class="likeandshare">
                                       <div style="margin-top: 15px" class="fb-like fb_iframe_widget" data-href="http://storediviss.com/" data-width="" data-layout="button" data-action="like" data-size="small" data-show-faces="true" data-share="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="action=like&amp;app_id=888164304637337&amp;container_width=0&amp;href=https%3A%2F%2Fwww.facebook.com%2Fnhacvnofficial%2F&amp;layout=button&amp;locale=vi_VN&amp;sdk=joey&amp;share=true&amp;show_faces=true&amp;size=small"><span style="vertical-align: bottom; width: 112px; height: 20px;"><iframe name="fdb1ba48de5b44" width="1000px" height="1000px" title="fb:like Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v2.3/plugins/like.php?action=like&amp;app_id=888164304637337&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D44%23cb%3Df20329085e4884c%26domain%3Dnhac.vn%26origin%3Dhttps%253A%252F%252Fnhac.vn%252Ff3f21c2ebd57f4%26relation%3Dparent.parent&amp;container_width=0&amp;href=https%3A%2F%2Fwww.facebook.com%2Fnhacvnofficial%2F&amp;layout=button&amp;locale=vi_VN&amp;sdk=joey&amp;share=true&amp;show_faces=true&amp;size=small" style="border: none; visibility: visible; width: 112px; height: 20px;" class=""></iframe></span></div>
                                </div>
                                <!-- end like and share -->
            
            
                                <div class="box-audio mt-3">
                                    <div class="row ">
                                        <div class="col-12 col-lg-4">
                                                <div class="player-suggest-login">
                                                    <a href="">
                                                            <figure>
                                                           
                                                                    <img src="./img/bg_player_thumb_ad.png" alt="" class="img-fluid">
                                                           
                                                           
                                                            
                                                        </figure>
                                                    </a>
                                                       
            
            
                                                    </div>
                                        </div>
                                        <div class="col-12 col-lg-8">
                                            <figcaption class="text-center">
                                                    <div class="innn">
                                                        <div class="namebh">
                                                            Nơi Này Có Anh
                                                        </div>
                                                        <div class="namesg">
                                                            Sơn Tùng MTP
                                                        </div>
                                                    </div>
                                                    <i class="fas fa-compact-disc fa-spin fa-6x"></i>
                                                    <audio controls class="">
                                                            <source src="./files/Noi-Nay-Co-Anh-Son-Tung-M-TP.mp3" type="audio/mpeg">
                                                        </audio>
                                            </figcaption>
                                        </div>
                                        
                                    </div>
                                   
                                  
                                </div>
            
            
                                <div class="box-icon mt-2">
                                    <div class="row">
                                        <div class="col-12">
                                                <ul>
                                                        <li>
                                                            <a href="#">
                                                                    <i class="far fa-heart"></i>
                                                                    Yêu thích
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                    <i class="far fa-plus-square"></i>
                                                                    Thêm vào
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                    <i class="fas fa-download"></i>
                                                                    Tải về máy
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                    <i class="fab fa-youtube"></i>
                                                                    Xem MV
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                    <i class="fas fa-share"></i>
                                                                    Chia sẽ
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                    <i class="fas fa-mobile-alt"></i>
                                                                    Cài nhạc chờ
                                                            </a>
                                                        </li>
                                                    </ul>
                                        </div>
                                    </div>
                                      
                                        </div>
                                <!-- end -->
                                <section class="lyrics">
                                   <div class="row">
                                      
                                       <div class="col-12">
                                           <div class="title-lyrics">
                                                    Lời bài hát
                                           </div>
                                           <div class="containlyrics">
                                                Em là ai từ đâu bước đến nơi đây dịu dàng chân phương <br>
                                                Em là ai tựa như ánh nắng ban mai ngọt ngào trong sương <br>
                                                Ngắm em thật lâu con tim anh yếu mềm <br>
                                                Đắm say từ phút đó từng giây trôi yêu thêm. <br>
            
                                                Bao ngày qua bình minh đánh thức xua tan bộn bề nơi anh <br>
                                                Bao ngày qua niềm thương nỗi nhớ bay theo bầu trời trong xanh <br>
                                                Liếc đôi hàng mi mong manh anh thẫn thờ br <br>
                                                Muốn hôn nhẹ mái tóc bờ môi em, anh mơ. <br>
                                                [ĐK:]
                                                    Cầm tay anh, dựa vai anh <br>
                                                    Kề bên anh nơi này có anh <br>
                                                    Gió mang câu tình ca <br>
                                                    Ngàn ánh sao vụt qua nhẹ ôm lấy em <br>
                                                    (Yêu em thương em con tim anh chân thành). <br>
            
                                                    Cầm tay anh, dựa vai anh <br>
                                                    Kề bên anh nơi này có anh <br>
                                                    Khép đôi mi thật lâu <br>
                                                    Nguyện mãi bên cạnh nhau <br>
                                                    Yêu say đắm như ngày đầu. <br>
            
                                                    Mùa xuân đến bình yên cho anh những giấc mơ <br>
                                                    Hạ lưu giữ ngày mưa ngọt ngào nên thơ <br>
                                                    Mùa thu lá vàng rơi đông sang anh nhớ em <br>
                                                    Tình yêu bé nhỏ xin dành tặng riêng em. <br>
            
                                                    [Rap:]
                                                    Còn đó tiếng nói ấy bên tai vấn vương bao ngày qua <br>
                                                    Ánh mắt bối rối nhớ thương bao ngày qua <br>
                                                    Yêu em anh thẫn thờ, con tim bâng khuâng đâu có ngờ <br>
                                                    Chẳng bao giờ phải mong chờ <br>
                                                    Đợi ai trong chiều hoàng hôn mờ <br>
                                                    Đắm chìm hòa vào vần thơ <br>
                                                    Ngắm nhìn khờ dại mộng mơ <br>
                                                    Đừng bước vội vàng rồi làm ngơ <br>
                                                    Lạnh lùng đó làm bộ dạng thờ ơ <br>
                                                    Nhìn anh đi em nha <br>
                                                    Hướng nụ cười cho riêng anh nha <br>
                                                    Đơn giản là yêu con tim anh lên tiếng thôi. <br>
            
                                                    * Uhhhhhhhh nhớ thương em <br>
                                                    Uhhhhhhhh nhớ thương em lắm <br>
                                                    Ahhhhhhh phía sau chân trời <br>
                                                    Có ai băng qua lối về cùng em đi trên đoạn đường dài.
                                           </div>
                                           <div class="xt">
                                                <i class="fas fa-arrow-down"></i>
                                           </div>
                                       </div>
                                   </div>
            
            
                                </section>
                                <section class="mvlist">
                                        <div class="ttmvlist">
                                                Album Sơn Tùng M-TP
                                        </div>
                                    <div class="row">
                                       
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst1.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst2.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst3.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst4.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                    </div>
                                    <div class="row">
                                       
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst1.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst2.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst3.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/abst4.jpg" alt="" class="img-fluid">
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                    </div>
                                </section>
                                <!-- end -->
                                <section class="videolist">
                                        <div class="ttvideolist">
                                                Video Sơn Tùng M-TP
                                        </div>
                                    <div class="row">
                                       
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost1.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost2.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost3.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost4.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                    </div>
                                    <div class="row">
                                       
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost1.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost2.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost3.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-6 col-lg-3">
                                                    <div class="list-album-item">
                                                        <figure>
                                                            <img src="img/videost4.jpg" alt="" class="img-fluid">
                                                            <div class="view">
                                                                    4:30
                                                                </div>
                                                        </figure>
                                                        <div class="infor">
                                                            <h3>
                                                                <a href="#">
                                                                    Khi Đã Yêu (Single)
                                                                </a>
                                                            </h3>
                                                            <h4>
                                                                <a href="#">
                    
                                                                   Sơn Tùng MTP
                                                                </a>
                                                                <a href="#">
                                                                   
                                                                </a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                    </div>
                                    
                                </section>
                                <!-- end -->
                                <section class="comment">
                                    <div class="title-cmt">
                                        Bình Luận
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="box-comment">
                                                <textarea name="" id="" style="width:100%" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <div class="col-12 col-lg-3">
                                <figure class="cdf">
                                    <img src="./img/sontung.jpg" alt="" class="img-fluid">
                                </figure>
                               
                            </div>
                </div>
               
            </div>



        </section>

        
    </main>
<!-- END MAIN -->


<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/singerdetails.blade.php ENDPATH**/ ?>