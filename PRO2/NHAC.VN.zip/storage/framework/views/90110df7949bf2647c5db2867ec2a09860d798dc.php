<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- phần content -->
    <div class="container">
        <div class="row mt-3">
                <!-- tin nóng -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="clearfix">
                            <div class="float-left title pl-5">
                                <a href="#">
                                    <h3>Tin nóng</h3>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="near-header">
                     <?php $__currentLoopData = $tintuchot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tintuchot2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="box-image">
                                <a href="<?php echo e(route('detailtintuc',$tintuchot2->id)); ?>">
                                    <img src="<?php echo e($tintuchot2->hinhanh_tintuc); ?>" alt="Tin Tức Hot">
                                </a>
                            </div>
                        </div>   
                        <div class="col-md-6">
                            <div class="text">
                                <div class="title-text">
                                    <a href="<?php echo e(route('detailtintuc',$tintuchot2->id)); ?>">
                                        <h3><?php echo e($tintuchot2->tieude_tintuc); ?></h3>
                                    </a>
                                </div>
                                <div class="detail-text">
                                    <p><?php echo e($tintuchot2->mota_tintuc); ?></p>
                                </div>
                                <a href="<?php echo e(route('detailtintuc',$tintuchot2->id)); ?>" class="view-detail">Xem chi tiết</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
        </div>
        <div class="box-hongsao">
            <div class="row">
                <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tintuc3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="<?php echo e(route('detailtintuc',$tintuc3->id)); ?>">
                                <img src="<?php echo e($tintuc3->hinhanh_tintuc); ?>" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="<?php echo e(route('detailtintuc',$tintuc3->id)); ?>">
                                    <?php echo e($tintuc3->tieude_tintuc); ?>

                                </a>
                            </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
         <div class="pages">
                <ul class="nav justify-content-center">
                    <li class="">
                        <?php echo e($tintuc->links()); ?>

                    </li>
                </ul>
            </div>

    </div>
    <!-- kết thúc phần content -->

<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views/client/hongsao.blade.php ENDPATH**/ ?>