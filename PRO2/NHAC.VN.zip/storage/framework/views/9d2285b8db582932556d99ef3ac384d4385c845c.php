<?php $__env->startSection('admin.admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách ca sĩ
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td>Tên ca sĩ</td>
            <td>Tên bài hát</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $detailcasi2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><span class="text-ellipsis"><?php echo e($emp3->hoten_casi); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->ten_baihat); ?></span></td>
            <td>
                <a href="update-detailcasi/<?php echo e($emp3->id_casi); ?>/baihat/<?php echo e($emp3->id_baihat); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a onclick="return confirm('Bạn có muốn xóa không?')" href="delete-detailcasi/<?php echo e($emp3->id_casi); ?>/baihat/<?php echo e($emp3->id_baihat); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NHAC.VN\resources\views/admin/qldetailcasi/ql_detailcasi.blade.php ENDPATH**/ ?>