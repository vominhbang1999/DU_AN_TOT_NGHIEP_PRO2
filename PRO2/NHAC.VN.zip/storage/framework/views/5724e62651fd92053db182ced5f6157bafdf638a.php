<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ===================================================  MAIN MUSIC VIDEO ============================================ -->
    <main>
        <section class="home-musicvideo mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9">
                        <div class="box_title box_title_filter">

                            <h1 class="name">Music Video</h1>
                            <div class="box-nav box-nav-ext">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home"
                                            role="tab" aria-controls="home" aria-selected="true">Mới Nhất</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile"
                                            role="tab" aria-controls="profile" aria-selected="false">Nghe Nhiều</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Yêu Thích</a>
                                    </li>

                                </ul>

                            </div>


                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                
                                <div class="row mobile4">

                                    <?php $__currentLoopData = $mv_moinhat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv_moinhat2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-lg-3 mb-1">
                                            <div class="thumb-hover">
                                                <a href="detailmv/<?php echo e($mv_moinhat2->id); ?>">
                                                    <figure>
                                                        <img src="<?php echo e(URL::asset($mv_moinhat2->hinh_baihat)); ?>"
                                                            alt="" class="img-fluid">
                                                            <div class="circle">

                                                            </div>
                                                    </figure>
                                                </a>
                                              
                                            </div>


                                            <div class="info">
                                                <h3 class="name over-text white"><a
                                                        href="detailmv/<?php echo e($mv_moinhat2->id); ?>"
                                                        title="<?php echo e($mv_moinhat2->ten_baihat); ?>"><?php echo e($mv_moinhat2->ten_baihat); ?></a>
                                                </h3>
                                                 <h4 class="singer over-text white singer-h4">

                                                <?php $__currentLoopData = $mv_moinhat2->casi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musiccasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a title="Quách Beem" href="detailcasi/<?php echo e($musiccasi->id); ?>"><?php echo e($musiccasi->hoten_casi); ?>

                                                        </a>  
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </h4>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </div>
                                <div class="duma4">
                                                      
                                    <i class="fas fa-arrow-down"></i>
                               </div>





                            </div>



                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">



                                    <div class="row mobile5">

                                    <?php $__currentLoopData = $mv_nghenhieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv_nghenhieu2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-lg-3 mb-1">
                                            <div class="thumb-hover">
                                                <a href="detailmv/<?php echo e($mv_nghenhieu2->id); ?>">
                                                    <figure>
                                                        <img src="<?php echo e(URL::asset($mv_nghenhieu2->hinh_baihat)); ?>"
                                                            alt="" class="img-fluid">
                                                            <div class="circle">

                                                            </div>
                                                    </figure>
                                                </a>
                                              
                                            </div>


                                            <div class="info">
                                                <h3 class="name over-text white"><a
                                                        href="detailmv/<?php echo e($mv_nghenhieu2->id); ?>"
                                                        title="<?php echo e($mv_moinhat2->ten_baihat); ?>"><?php echo e($mv_nghenhieu2->ten_baihat); ?></a>
                                                </h3>
                                                <h4 class="singer over-text white singer-h4">
                                                 <?php $__currentLoopData = $mv_nghenhieu2->casi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musiccasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                        <a title="Quách Beem" href="detailcasi/<?php echo e($musiccasi->id); ?>"><?php echo e($musiccasi->hoten_casi); ?>

                                                        </a>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </h4>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>

                                        <div class="duma5">
                                                      
                                            <i class="fas fa-arrow-down"></i>
                                       </div>
                            </div>

                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="row mobile5">

                                    <?php $__currentLoopData = $mv_yeuthich; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv_yeuthich2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-lg-3 mb-1">
                                            <div class="thumb-hover">
                                                <a href="detailmv/<?php echo e($mv_yeuthich2->id); ?>">
                                                    <figure>
                                                        <img src="<?php echo e(URL::asset($mv_yeuthich2->hinh_baihat)); ?>"
                                                            alt="" class="img-fluid">
                                                            <div class="circle">

                                                            </div>
                                                    </figure>
                                                </a>
                                              
                                            </div>


                                            <div class="info">
                                                <h3 class="name over-text white"><a
                                                        href="detailmv/<?php echo e($mv_yeuthich2->id); ?>"
                                                        title="<?php echo e($mv_moinhat2->ten_baihat); ?>"><?php echo e($mv_yeuthich2->ten_baihat); ?></a>
                                                </h3>
                                                <h4 class="singer over-text white singer-h4">
                                                <?php $__currentLoopData = $mv_yeuthich2->casi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musiccasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                        <a title="Quách Beem" href="detailcasi/<?php echo e($musiccasi->id); ?>"><?php echo e($musiccasi->hoten_casi); ?>

                                                        </a>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </h4>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>

                                        <div class="duma5">
                                                      
                                            <i class="fas fa-arrow-down"></i>
                                       </div>
                            </div>
                            </div>

                        </div>
                    <!-- END -->
                    <div class="col-12 col-lg-3">
                        <figure class="mt-3 mb-5" id="sontung">
                            <img src="<?php echo e($nhacviet[0]->avatar_casi); ?>" alt="" class="img-fluid">
                        </figure>
                        <div class="box-bxh" >
                                <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                          <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Việt Nam</a>
                                          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Âu Mỹ</a>
                                          <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Hàn Quốc</a>
                                        </div>
                                      </nav>
                                      <div class="tab-content" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                                <ul class="mobile" >
                                                        <li class="chart_song_item">
                                                            <div class="box-ranks">
                                                                    <a href="detailmv/<?php echo e($nhacviet[0]->id); ?>">
                                                                        <figure>
                                                                            <img style="width: 100px;" src="<?php echo e($nhacviet[0]->hinh_baihat); ?>;" alt="" class="img-fluid">
                                                                            <span>
                                                                                01
                                                                            </span>
                                                                        </figure>
            
                                                                    </a><div class="infor_n">
                                                                        <h3>

                                                                            <a href="detailmv/<?php echo e($nhacviet[0]->id); ?>">
                                                                                <?php echo e($nhacviet[0]->ten_baihat); ?>

                                                                            </a>
        
                                                                        </h3>
                                                                        <p class="chat-song-top1">
                                                                            <a href="detailcasi/<?php echo e($nhacviet[0]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[0]->hoten_casi); ?>

                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            
                                                        </li>
                                                        <!-- end top1 -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt" id="red">
                                                                        02
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[1]->id); ?>">
                                                                            <?php echo e($nhacviet[1]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[1]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[1]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        03
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[2]->id); ?>">
                                                                           <?php echo e($nhacviet[2]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[2]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        04
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[3]->id); ?>">
                                                                           <?php echo e($nhacviet[3]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[2]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[4]->id); ?>">
                                                                            <?php echo e($nhacviet[4]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[2]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[5]->id); ?>">
                                                                           <?php echo e($nhacviet[5]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[5]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[5]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[6]->id); ?>">
                                                                            <?php echo e($nhacviet[6]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[6]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[6]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[7]->id); ?>">
                                                                            <?php echo e($nhacviet[7]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[7]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[7]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[8]->id); ?>">
                                                                           <?php echo e($nhacviet[8]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[8]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[8]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacviet[9]->id); ?>">
                                                                            <?php echo e($nhacviet[9]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacviet[9]->id_casi); ?>">
                                                                                <?php echo e($nhacviet[9]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                       
                                                        
                                                    </ul>
                                                    <div class="duma" >
                                                      
                                                            <i class="fas fa-arrow-down"></i>
                                                       </div>
                                                   
                                        </div>





                                        <!-- ssss -->
                                        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                                <ul class="mobile" >
                                                        <li class="chart_song_item">
                                                            <div class="box-ranks">
                                                                    <a href="detailmv/<?php echo e($nhacaumi[0]->id); ?>">
                                                                        <figure>
                                                                            <img style="width: 100px;" src="<?php echo e($nhacaumi[0]->hinh_baihat); ?>;" alt="" class="img-fluid">
                                                                            <span>
                                                                                01
                                                                            </span>
                                                                        </figure>
            
                                                                    </a><div class="infor_n">
                                                                        <h3>

                                                                            <a href="detailmv/<?php echo e($nhacaumi[0]->id); ?>">
                                                                                <?php echo e($nhacaumi[0]->ten_baihat); ?>

                                                                            </a>
        
                                                                        </h3>
                                                                        <p class="chat-song-top1">
                                                                            <a href="detailcasi/<?php echo e($nhacaumi[0]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[0]->hoten_casi); ?>

                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            
                                                        </li>
                                                        <!-- end top1 -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt" id="red">
                                                                        02
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[1]->id); ?>">
                                                                            <?php echo e($nhacaumi[1]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[1]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[1]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        03
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[2]->id); ?>">
                                                                           <?php echo e($nhacaumi[2]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[2]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        04
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[3]->id); ?>">
                                                                           <?php echo e($nhacaumi[3]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[2]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[4]->id); ?>">
                                                                            <?php echo e($nhacaumi[4]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[2]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[5]->id); ?>">
                                                                           <?php echo e($nhacaumi[5]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[5]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[5]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[6]->id); ?>">
                                                                            <?php echo e($nhacaumi[6]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[6]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[6]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[7]->id); ?>">
                                                                            <?php echo e($nhacaumi[7]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[7]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[7]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[8]->id); ?>">
                                                                           <?php echo e($nhacaumi[8]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[8]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[8]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacaumi[9]->id); ?>">
                                                                            <?php echo e($nhacaumi[9]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacaumi[9]->id_casi); ?>">
                                                                                <?php echo e($nhacaumi[9]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                       
                                                        
                                                    </ul>
                                            <div class="duma2" >
                                                    <i class="fas fa-arrow-down"></i>
                                               </div>
                                            
                                        </div>
                                        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"> 
                                            <ul class="mobile" >
                                                        <li class="chart_song_item">
                                                            <div class="box-ranks">
                                                                    <a href="detailmv/<?php echo e($nhacchaua[0]->id); ?>">
                                                                        <figure>
                                                                            <img style="width: 100px;" src="<?php echo e($nhacchaua[0]->hinh_baihat); ?>;" alt="" class="img-fluid">
                                                                            <span>
                                                                                01
                                                                            </span>
                                                                        </figure>
            
                                                                    </a><div class="infor_n">
                                                                        <h3>

                                                                            <a href="detailmv/<?php echo e($nhacchaua[0]->id); ?>">
                                                                                <?php echo e($nhacchaua[0]->ten_baihat); ?>

                                                                            </a>
        
                                                                        </h3>
                                                                        <p class="chat-song-top1">
                                                                            <a href="detailcasi/<?php echo e($nhacchaua[0]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[0]->hoten_casi); ?>

                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            
                                                        </li>
                                                        <!-- end top1 -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt" id="red">
                                                                        02
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[1]->id); ?>">
                                                                            <?php echo e($nhacchaua[1]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[1]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[1]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        03
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[2]->id); ?>">
                                                                           <?php echo e($nhacchaua[2]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[2]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        04
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[3]->id); ?>">
                                                                           <?php echo e($nhacchaua[3]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[2]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[4]->id); ?>">
                                                                            <?php echo e($nhacchaua[4]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[2]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[2]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[5]->id); ?>">
                                                                           <?php echo e($nhacchaua[5]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[5]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[5]->hoten_casi); ?>

                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[6]->id); ?>">
                                                                            <?php echo e($nhacchaua[6]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[6]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[6]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[7]->id); ?>">
                                                                            <?php echo e($nhacchaua[7]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[7]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[7]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[8]->id); ?>">
                                                                           <?php echo e($nhacchaua[8]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[8]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[8]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="detailmv/<?php echo e($nhacchaua[9]->id); ?>">
                                                                            <?php echo e($nhacchaua[9]->ten_baihat); ?>

                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="detailcasi/<?php echo e($nhacchaua[9]->id_casi); ?>">
                                                                                <?php echo e($nhacchaua[9]->hoten_casi); ?>

                                                                        </a>

                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>

                                                       
                                                        
                                                    </ul>
                                        <div class="duma3" >
                                                <i class="fas fa-arrow-down"></i>
                                           </div>
                                       
                                    </div>
                                      </div>
                        </div>
                        
                    </div>
                </div>
            </div>



        </section>





    </main>
<!-- ===================================================  MAIN MUSIC VIDEO ============================================ -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NHAC.VN\resources\views/client/musicvideo.blade.php ENDPATH**/ ?>