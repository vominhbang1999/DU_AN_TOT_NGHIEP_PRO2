<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <section class="detailtintuc mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9">
                        <div class="box-content">
                            <h1 class="news-detail-box-title">
                                <?php echo e($detailtintuc->tieude_tintuc); ?> </h1>
                            <div class="news-detail-box-time">
                                <?php echo e(Carbon\Carbon::parse($detailtintuc->created_at)->format('d-m-Y')); ?>

                                 </div>
                            <div class="news-detail-box-m">

                                <div class="news-social-link" id="news-social-link">
                                    <div style="margin-top: 15px" class="fb-like fb_iframe_widget" data-href="http://storediviss.com/" data-width="" data-layout="button" data-action="like" data-size="small" data-show-faces="true" data-share="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="action=like&amp;app_id=&amp;container_width=112&amp;href=http%3A%2F%2Fstorediviss.com%2F&amp;layout=button&amp;locale=vi_VN&amp;sdk=joey&amp;share=true&amp;show_faces=true&amp;size=small"><span style="vertical-align: bottom; width: 112px; height: 20px;"><iframe name="f2cfda9fafc8c2" width="1000px" height="1000px" title="fb:like Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v4.0/plugins/like.php?action=like&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D44%23cb%3Df3a20ad069f679%26domain%3D%26origin%3Dfile%253A%252F%252F%252Ff12cc4850e407d8%26relation%3Dparent.parent&amp;container_width=112&amp;href=http%3A%2F%2Fstorediviss.com%2F&amp;layout=button&amp;locale=vi_VN&amp;sdk=joey&amp;share=true&amp;show_faces=true&amp;size=small" style="border: none; visibility: visible; width: 130px; height: 20px;" class=""></iframe></span></div>

                                </div>
                                <div class="news-detail-box-des">
                                    <?php echo e($detailtintuc->mota_tintuc); ?>

                                </div>
                                <div class="news-detail-box-content">
                                    <figure class="Sepia">
                                            <img class="img-fluid" style="width: 100%" 
                                        src="<?php echo e(URL::asset($detailtintuc->hinhanh_tintuc)); ?>"
                                        >
                                    </figure>
                                    <p dir="ltr">
                                        <?php echo e($detailtintuc->noidung_tintuc); ?>

                                    </p> 


                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                    <div class="box_title box_title_related_news" style="padding-top: 10px ; border-top: #5e6773 solid 1px;">
                                            <h2 class="name">Tin mới</h2>
                                        </div>
                            </div>
                            <!-- START NEW TIN -->
                            <?php $__currentLoopData = $tintucmoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tintucmoi2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-lg-3">
                                <div class="news-list-sm-box-item">
                                    <a href="<?php echo e(route('detailtintuc',$tintucmoi2->id)); ?>" class="news-list-sm-box-item-img "><figure>
                                            <img  class="img-fluid " style="width: auto;
height: 110px;" src="<?php echo e(URL::asset($tintucmoi2->hinhanh_tintuc)); ?>" alt="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát" title="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát">
                                    </figure></a>
                                    <div class="info">
                                        <p class="title">
                                            <a href="<?php echo e(route('detailtintuc',$tintucmoi2->id)); ?>"><?php echo e($tintucmoi2->tieude_tintuc); ?></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                            <!-- END LIST NEW TIN -->
                            <?php if(Auth::check()): ?>
                                <div class="col-12">
                                    <div id="comment" class="box box-comment mgt-15 mb-5">
                                        <div class="box_title">
                                            <h2 class="name nobg" style="color: #fff; padding-top: 10px ; border-top: #5e6773 solid 1px;">Bình luận</h2>
                                        </div>
                                        <div class="box_content">
                                            <form method="post" action="/binhluan/<?php echo e($detailtintuc->id); ?>">
                                                <textarea required placeholder="Nhập nội dung"  rows="5"  name="noidung" class="form-control" style="width: 100%;"></textarea>
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                                <input type="submit" name="submit" value="Gửi" class="btn btn-success mt-3">

                                            </form>

                                        </div>
                                        <!-- =========================== PHẦN BÌNH LUẬN ====================== -->
                                    <div class="cacbinhluan">
                                         <?php $__currentLoopData = $hienthi_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hienthi_comment1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <!-- ============BÌNH LUẬN CHA============== -->
                                            <div class="comment_cha">

                                                <div class="info-user-comment cantrai mt-3">
                                                    <a class="nav-link" href="#">
                                                        <figure>
                                                            <img style="width:30px;height:30px;border-radius:50%" src="
                                                            <?php echo e(URL::asset($hienthi_comment1->hinhanh)); ?>" alt="">
                                                        </figure>
                                                     </a>
                                                     <a class="nav-link" style="margin-top: -2rem; margin-left: -1rem;" href="#">
                                                        <span style="color: #fff"><?php echo e($hienthi_comment1->name); ?></span>
                                                    </a>
                                                </div>

                                                <div class="thoigianbinhluan">
                                                    <p>
                                                        <?php echo e(\Carbon\Carbon::parse($hienthi_comment1->created_at)->format('d/m/Y H:i:s')); ?>

                                                    </p>
                                                </div>
                                               
                                                <div class="noidungbinhluan cangiua">

                                                    <div class="text">
                                                        <span>
                                                            <?php echo e($hienthi_comment1->noidung_binhluan); ?>

                                                        </span>
                                                    </div>

                                                    <div class="form-traloi">
                                                        <form  class="mt-3" action="/replycomment/<?php echo e($detailtintuc->id); ?>" method="post">
                                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                            <input type="hidden" name="parent_id" value="<?php echo e($hienthi_comment1->id); ?>">
                                                            <div class="form-group">
                                                                <textarea class="form-control" rows="2" name="noidung_binhluan"></textarea>
                                                            </div>
                                                            <div class="form-group w-100 text-right" >
                                                                <input type="button" class="btn btn-success  huyreply  p-2 w-10"  name="submit" value="Hủy" style="margin-top: -1rem; font-size: 13px">
                                                                <input type="submit" class="btn btn-success  p-2 w-10"  name="submit" value="Gửi" style="margin-top: -1rem; font-size: 13px">

                                                            </div>
                                                        </form>
                                                    </div>

                                                     <div class="form-update-binhluan">
                                                        <form  class="mt-3" action="/updatebl/<?php echo e($hienthi_comment1->id); ?>" method="post">
                                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                            <div class="form-group">
                                                                <textarea class="form-control" rows="2" name="noidung_binhluan"><?php echo e($hienthi_comment1->noidung_binhluan); ?></textarea>
                                                            </div>
                                                            <div class="form-group w-100 text-right" >
                                                                <input type="button" class="btn btn-success  huyupdate  p-2 w-10"  name="submit" value="Hủy" style="margin-top: -1rem; font-size: 13px">
                                                                <input type="submit" class="btn btn-success  p-2 w-10"  name="submit" value="Gửi" style="margin-top: -1rem; font-size: 13px">

                                                            </div>
                                                        </form>
                                                    </div>

                                                    <?php if(Auth::user()->id === $hienthi_comment1->id_user): ?>
                                                        <div class="chinhsua">
                                                            <span>
                                                                <span  id="editcomment" style="color: #fff; cursor: pointer ; text-decoration: none" href="#"  alt="">
                                                                    <i class="far fa-edit"></i>
                                                                </span>
                                                            </span>
                                                            <span class="mr-2">
                                                                <a href="../deletecomment/<?php echo e($hienthi_comment1->id); ?>"  alt="" style="color: #fff">
                                                                    <i class="fas fa-times"></i>
                                                                </a>
                                                            </span>
                                                            <span class="replycomment" style="cursor: pointer;">
                                                                Trả lời
                                                            </span>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="chinhsua">
                                                            <span class="replycomment" style="cursor: pointer;">
                                                                Trả lời
                                                            </span>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                </div>
                                                <div class="xemthemcomment">
                                                    <span > 
                                                        <i class="fas fa-arrow-down"></i> 
                                                        xem thêm
                                                    </span>
                                                </div>
                                                 <div class="ancomment">
                                                    <span > 
                                                        <i class="fas fa-arrow-up"></i> 
                                                        Ẩn
                                                    </span>
                                                </div>



                                            <!-- =========BÌNH LUẬN CON============ -->
                                            <?php $__currentLoopData = $hienthi_comment_reply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hienthi_comment_reply2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($hienthi_comment1->id == $hienthi_comment_reply2->parent_id): ?>
                                                    <div class="comment_con" style="padding-left: 5rem">
                                                        <div class="info-user-comment cantrai mt-1">
                                                            <a class="nav-link" href="#">
                                                                <figure>
                                                                    <img style="width:30px;height:30px;border-radius:50%" src="<?php echo e(URL::asset($hienthi_comment1->hinhanh)); ?>" alt="">
                                                                </figure>
                                                             </a>
                                                             <a class="nav-link" style="margin-top: -2rem; margin-left: -1rem;" href="#">
                                                                <span style="color: #fff"><?php echo e($hienthi_comment_reply2->name); ?></span>
                                                            </a>
                                                        </div>

                                                        <div class="thoigianbinhluan">
                                                            <p>
                                                                <?php echo e(\Carbon\Carbon::parse($hienthi_comment_reply2->created_at)->format('d/m/Y H:i:s')); ?>

                                                            </p>
                                                        </div>
                                                       
                                                        <div class="noidungbinhluan cangiua">
                                                         <div class="form-traloi">
                                                            <form  class="mt-3" action="/replycomment/<?php echo e($detailtintuc->id); ?>" method="post">
                                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                <input type="hidden" name="parent_id" value="<?php echo e($hienthi_comment1->id); ?>">
                                                                <div class="form-group">
                                                                    <textarea class="form-control" rows="2" name="noidung_binhluan"></textarea>
                                                                </div>
                                                                <div class="form-group w-100 text-right" >
                                                                    <input type="button" class="btn btn-success  huyreply  p-2 w-10"  name="submit" value="Hủy" style="margin-top: -1rem; font-size: 13px">
                                                                    <input type="submit" class="btn btn-success  p-2 w-10"  name="submit" value="Gửi" style="margin-top: -1rem; font-size: 13px">

                                                                </div>
                                                            </form>
                                                        </div>

                                                         <div class="form-update-binhluan">
                                                            <form  class="mt-3" action="/updatebl/<?php echo e($hienthi_comment_reply2->id); ?>" method="post">
                                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                <div class="form-group">
                                                                    <textarea class="form-control" rows="2" name="noidung_binhluan"><?php echo e($hienthi_comment_reply2->noidung_binhluan); ?></textarea>
                                                                </div>
                                                                <div class="form-group w-100 text-right" >
                                                                    <input type="button" class="btn btn-success  huyupdate  p-2 w-10"  name="submit" value="Hủy" style="margin-top: -1rem; font-size: 13px">
                                                                    <input type="submit" class="btn btn-success  p-2 w-10"  name="submit" value="Gửi" style="margin-top: -1rem; font-size: 13px">
                                                                </div>
                                                            </form>
                                                        </div>

                                                            <div class="text">
                                                                <span>
                                                                    <?php echo e($hienthi_comment_reply2->noidung_binhluan); ?>

                                                                </span>
                                                            </div>
                                                            <div class="updatebinhluan">
                                                                

                                                                <div class="close">
                                                                    <i class="fas fa-times-circle"></i>
                                                                </div>
                                                                <div class="tab-panner" style="background-color: #2a5f50;">
                                                                    <ul class="nav" style="display: contents;text-align: center;">
                                                                        <li  >
                                                                            <a href="#" class="nav-link" style="color: white" >Chỉnh Sữa Bình Luận</a>
                                                                        </li>
                                                                    </ul>
                                                                    
                                                                </div>
                                                                    <form  class="mt-3" action="/updatebl/<?php echo e($hienthi_comment1->id); ?>" method="post">
                                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                       <div class="form-group">
                                                                            <textarea class="form-control" rows="3" name="noidung_binhluan"><?php echo e($hienthi_comment1->noidung_binhluan); ?></textarea>
                                                                        </div>
                                                                        <input type="submit" class="btn btn-success w-100" name="submit" value="update">
                                                                    </form>
                                                            </div>
                                                            <?php if(Auth::user()->id === $hienthi_comment1->id_user): ?>
                                                                <div class="chinhsua">
                                                                    <span>
                                                                        <span id="editcomment" style="color: #fff; cursor: pointer ; text-decoration: none" href="#"  alt="">
                                                                            <i class="far fa-edit"></i>
                                                                        </span>
                                                                    </span>
                                                                    <span class="mr-2">
                                                                        <a href="../deletecomment/<?php echo e($hienthi_comment1->id); ?>"  alt="" style="color: #fff">
                                                                            <i class="fas fa-times"></i>
                                                                        </a>
                                                                    </span>
                                                                    <span class="replycomment" style="cursor: pointer;">
                                                                        Trả lời
                                                                    </span>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="chinhsua">
                                                                    <span class="replycomment" style="cursor: pointer;">
                                                                        Trả lời
                                                                    </span>
                                                                </div>
                                                            <?php endif; ?>
                                                           
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- =========BÌNH LUẬN CON============ -->


                                            </div>




                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- =========BÌNH LUẬN CHA============ -->

                                       

                                    </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-12">
                                    <div id="comment" class="box box-comment mgt-15 mb-5">
                                        <div class="box_title">
                                            <h2 class="name nobg" style="color: #fff; padding-top: 10px ; border-top: #5e6773 solid 1px;">Bình luận</h2>
                                        </div>
                                        <div class="box_content">
                                            <form action="" method="">
                                                <textarea name="" placeholder="Đăng nhập để bình luận" disabled id=""  rows="5" style="width: 100%;"></textarea>
                                                <input type="submit" name="submit" value="Gửi" class="btn btn-success">
                                            </form>
                                        </div>
                                                <!-- ================= PHẦN BÌNH LUẬN ======================== -->

                                    <div class="cacbinhluan">
                                         <?php $__currentLoopData = $hienthi_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hienthi_comment1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <!-- ============BÌNH LUẬN CHA============== -->
                                            <div class="comment_cha">
                                                <div class="xemthemcomment">
                                                    <span>
                                                        <i class="fas fa-arrow-down"></i>
                                                    </span>
                                                </div>
                                                <div class="info-user-comment cantrai mt-3">
                                                    <a class="nav-link" href="#">
                                                        <figure>
                                                            <img style="width:30px;height:30px;border-radius:50%" src="
                                                            <?php echo e(URL::asset($hienthi_comment1->hinhanh)); ?>" alt="">
                                                        </figure>
                                                     </a>
                                                     <a class="nav-link" style="margin-top: -2rem; margin-left: -1rem;" href="#">
                                                        <span style="color: #fff"><?php echo e($hienthi_comment1->name); ?></span>
                                                    </a>
                                                </div>

                                                <div class="thoigianbinhluan">
                                                    <p>
                                                        <?php echo e(\Carbon\Carbon::parse($hienthi_comment1->created_at)->format('d/m/Y H:i:s')); ?>

                                                    </p>
                                                </div>
                                               
                                                <div class="noidungbinhluan cangiua">

                                                    <div class="text">
                                                        <span>
                                                            <?php echo e($hienthi_comment1->noidung_binhluan); ?>

                                                        </span>
                                                    </div>                                                   
                                                </div>
                                                <?php $__currentLoopData = $hienthi_comment_reply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hienthi_comment_reply2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($hienthi_comment1->id == $hienthi_comment_reply2->parent_id): ?>
                                                        <div class="comment_con" style="padding-left: 5rem">
                                                            <div class="info-user-comment cantrai mt-1">
                                                                <a class="nav-link" href="#">
                                                                    <figure>
                                                                        <img style="width:30px;height:30px;border-radius:50%" src="<?php echo e(URL::asset($hienthi_comment1->hinhanh)); ?>" alt="">
                                                                    </figure>
                                                                 </a>
                                                                 <a class="nav-link" style="margin-top: -2rem; margin-left: -1rem;" href="#">
                                                                    <span style="color: #fff"><?php echo e($hienthi_comment_reply2->name); ?></span>
                                                                </a>
                                                            </div>

                                                            <div class="thoigianbinhluan">
                                                                <p>
                                                                    <?php echo e(\Carbon\Carbon::parse($hienthi_comment_reply2->created_at)->format('d/m/Y H:i:s')); ?>

                                                                </p>
                                                            </div>
                                                           
                                                            <div class="noidungbinhluan cangiua">

                                                                <div class="text">
                                                                    <span>
                                                                        <?php echo e($hienthi_comment_reply2->noidung_binhluan); ?>

                                                                    </span>
                                                                </div>
                                                            
                                                               
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        
                                                    <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- =========BÌNH LUẬN CHA============ -->


                                            <!-- =========BÌNH LUẬN CON============ -->

                                            <!-- =========BÌNH LUẬN CON============ -->
                                       

                                    </div>
                                </div>
                                </div>
                            <?php endif; ?>
                       
                        </div>



                </div>
                              

                        <div class="col-12 col-lg-3">
                            <div class="box-aaa">
                                <figure class="Brightness">
                                    <img src="<?php echo e(URL::asset('./img/detailtintuc6.jpg')); ?>" alt="" class="img-fluid">
                                </figure>
                                <div class="box_title">
                                    <h2 class="name"><a href="/hot-list" title="Chủ đề nổi bật">Chủ đề nổi bật</a></h2>
                                </div>
                                <figure  class="Brightness">
                                    <img src="<?php echo e(URL::asset('./img/detailtintuc5.jpg')); ?>" class="img-fluid" >
                                </figure>
                                <figure  class="Brightness">
                                    <img src="<?php echo e(URL::asset('./img/detailtintuc4.jpg')); ?>" class="img-fluid" alt="topic image">
                                </figure>
                                <figure  class="Brightness">
                                    <img src="<?php echo e(URL::asset('./img/detailtintuc3.jpg')); ?>" class="img-fluid" alt="topic image">
                                </figure>
                                <figure  class="Brightness">
                                    <img src="<?php echo e(URL::asset('./img/detailtintuc2.jpg')); ?>" class="img-fluid" >
                                </figure>
                            </div>                          
                        </div>
                    </div>
                </div>
        </section>
        



    </main>



</div>
    <!-- END FORM -->

    <!-- END MAIN -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views/client/detailtintuc.blade.php ENDPATH**/ ?>