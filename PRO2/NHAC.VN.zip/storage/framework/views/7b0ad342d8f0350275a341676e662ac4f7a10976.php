<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
            <div class="banner-mv">
                <div class="overlay"></div>
                <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
                  <source src="img/mv/video.mp4" type="video/mp4">
                </video>
                <div class="container h-100">
                  <div class="d-flex h-100 text-center align-items-center">
                    <div class="w-100 text-white">
                      <img src="img/vip/logo.png" class="display-3" />
                      <h1 class="lead mb-0">Những MV hấp dẫn nhất đều có ở Music.vn</h1>
                    </div>
                  </div>
                </div>
            </div>
        <div class="container">
            <div class="row musicvideo">
                <div class="col-12 hb col-md-10 col-lg-8">
                    <div class="title row">
                        <nav class="navbar navbar-expand-lg">
                            <h1>
                                <a class="" href="#">Music Video</a>
                            </h1>
                            <div class="menu collapse navbar-collapse">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="" href="#">Mới nhất</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="active" href="#">Nghe nhiều</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                        <hr>
                    </div>
                    <!-- ./ title -->
                    <div class="list-video row">
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1002.jpg" class="img-fluid" />
                                            <div class="duration">
                                               05:38
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Đừng Xa Em Đêm Nay (Acoustic)</h5></a>
                                            <a href="#"><p>Quỳnh Trang</p></a>
                                        </div>
                                    </div>
                        </div>
                       
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="#"><div class="video-img">
                                            <img src="img/mv/1003.jpg" class="img-fluid" />
                                            <div class="duration">
                                                05:21
                                            </div>
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="#"><h5>Khi Đã Yêu</h5></a>
                                            <a href="#"><p>Đan Trường, Trung Quang</p></a>
                                        </div>
                                    </div>
                        </div> 
                       
                       
                           
                        
                       
                       
                     
                      
                       
                      
                       
                    </div>
                    <!-- ./ list-video -->
                </div>
                <div class="col-12  col-md-2 col-lg-4 ht wow flipInX" data-wow-duration="2s" data-wow-delay=".3s">
                    <a href="#">
                        
                        <figure>
                                <img src="img/mv/banner.jpg"  class="img-fluid"/>
                        </figure>
                        
                        </a>
                </div>
            </div>
            <div class="pages">
                <ul class="nav justify-content-center">
                    <li class="">
                        <a class="btn" href="#">1</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">2</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">3</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">4</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">5</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">6</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">7</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">8</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">9</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">10</a>
                    </li>
                    <li class="">
                        <a class="btn" href="#">»</a>
                    </li>
                </ul>
            </div>
            <!-- ./ pages -->
        </div>
        <!-- ./ container -->
    </main>
    <!-- ./ main -->
    <!-- START FOOTER -->
<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/musicvideo.blade.php ENDPATH**/ ?>