<?php $__env->startSection('admin.admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm chi tiết Ca sĩ
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action="store_casi_detail" method="get">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Ca sĩ</label>
                            <select class="form-control"  name='casidetail' id="exampleFormControlInput1" >
                                <?php $__currentLoopData = $detailcasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailcasi3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($detailcasi3->id); ?>"><?php echo e($detailcasi3->hoten_casi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Bài Hát</label>
                            <select class="form-control"  name='songdetail' id="exampleFormControlInput1" >
                                <?php $__currentLoopData = $detailbaihat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailbaihat3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($detailbaihat3->id); ?>"><?php echo e($detailbaihat3->ten_baihat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <input type="submit" name="save" class="btn btn-info" value='INSERT'/>
                        
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NHAC.VN\resources\views/admin/qldetailcasi/insert_detailcasi.blade.php ENDPATH**/ ?>