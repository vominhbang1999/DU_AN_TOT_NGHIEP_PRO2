<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- phần content -->
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-12">
                <!-- tin nóng -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="clearfix">
                            <div class="float-left title">
                                <a href="#">
                                    <h3>Tin nóng</h3>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="near-header">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="box-image">
                                <a href="#">
                                    <img src="img/tinnong.jpg">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="text">
                                <div class="title-text">
                                    <a href="#">
                                        <h3>Hà Anh Tuấn - chàng trai “bình thường” với gu âm nhạc chưa bao giờ tầm thường</h3>
                                    </a>
                                </div>
                                <div class="detail-text">
                                    <p>"Chúng ta không cần là một người giỏi văn để có thể trở thành một người viết truyện…" - Hà Anh Tuấn đã chia sẻ như vậy vào đêm diễn Gấu tại Đà Lạt năm ngoái. Hình ảnh 5.000 khán giả che dù dưới mưa bay của Đà Lạt vẫn
                                        chưa phai mờ thì năm nay, người yêu “những nỗi buồn đẹp trong tình yêu” của nam ca sĩ lại đắm mình trong buổi hòa nhạc đúng sở trường lãng mạn mang tên Truyện Ngắn.</p>
                                </div>
                                <a href="#" class="view-detail">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box-hongsao">
            <div class="row">
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                Hà Anh Tuấn - chàng trai “bình thường” với gu âm nhạc chưa bao giờ tầm thường</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong1.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    Thanh toán gói VIP Nhac.vn bằng Ví MoMo, hoàn tiền giá trị</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong2.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    DTAP, bộ ba nhà sản xuất trẻ “vẽ” thành công của nhạc phim Anh Thầy Ngôi Sao</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box-hongsao">
            <div class="row">
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong3.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    “Bài Ca Tôm Cá” - câu hò tiếp năng lượng cho hành trình theo đuổi đam mê</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong4.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    Senorita – Một bài hát “khôn ngoan” cho cả Shawn Mendes và Camila Cabello</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong5.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    Âm nhạc - Bạn đồng hành của những chuyến đi</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box-hongsao">
            <div class="row">
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong6.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    ‘Hương Thời Gian’ - Bản ballad ngọt ngào của Nguyễn Phi Hùng</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong7.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    Nguyễn Phi Hùng, soái ca độc thân đa tài của làng showbiz Việt</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box-detail">
                        <div class="box-image">
                            <a href="#">
                                <img src="img/tinnong8.jpg" alt="">
                            </a>
                        </div>
                        <div class="box-text">
                            <p>
                                <a href="#">
                                    Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu của Sơn Tùng M-TP</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- kết thúc phần content -->

<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/hongsao.blade.php ENDPATH**/ ?>