<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <section class="album duy mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9">
                        <div class="box_title box_title_filter">

                            <h1 class="name">ALBUM</h1>
                            <div class="box-nav box-nav-ext">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home"
                                            role="tab" aria-controls="home" aria-selected="true">Mới Nhất</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile"
                                            role="tab" aria-controls="profile" aria-selected="false">Nghe Nhiều</a>
                                    </li>

                                </ul>

                            </div>


                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                
                                <div class="row mobile4">
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>
                                    <div class="col-6 col-lg-3 mb-1">
                                        <div class="thumb-hover">
                                            <a href="#">
                                                <figure>
                                                    <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                        alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                        <div class="circle">



                                                        </div>
                                                </figure>
                                            </a>
                                          
                                        </div>


                                        <div class="info">
                                            <h3 class="name over-text white"><a
                                                    href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                    title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                            <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                    href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                        </div>
                                    </div>



                                </div>
                                <div class="duma4">
                                                      
                                    <i class="fas fa-arrow-down"></i>
                               </div>





                            </div>








                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">



                                    <div class="row mobile5">

                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/c/e/1/6/ce161f3daeb2baa22c3f825350cec6b3.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                            <div class="col-6 col-lg-3 mb-1">
                                                <div class="thumb-hover">
                                                    <a href="#">
                                                        <figure>
                                                            <img src="https://photo-resize-zmp3.zadn.vn/w480_r1x1_jpeg/cover/d/0/e/4/d0e46ae68f982976d6f19f344a685dc2.jpg"
                                                                alt="Hà Giang Ơi (Single) - Quách Beem" class="img-fluid">
                                                                <div class="circle">
        
        
        
                                                                </div>
                                                        </figure>
                                                    </a>
                                                  
                                                </div>
        
        
                                                <div class="info">
                                                    <h3 class="name over-text white"><a
                                                            href="https://nhac.vn/album/ha-giang-oi-single-quach-beem-abjMnGNR"
                                                            title="Hà Giang Ơi (Single)">Hà Giang Ơi (Single)</a></h3>
                                                    <h4 class="singer over-text white singer-h4"><a title="Quách Beem"
                                                            href="https://nhac.vn/nghe-si/quach-beem-at8Dv7">Quách Beem</a></h4>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="duma5">
                                                      
                                            <i class="fas fa-arrow-down"></i>
                                       </div>
                            </div>

                        </div>
                    </div>
                    <!-- END -->
                    <div class="col-12 col-lg-3">
                        <figure class="mt-3 mb-5" id="sontung">
                            <img src="./img/sontung05-177a.jpg" alt="" class="img-fluid">
                        </figure>
                        <div class="box-bxh" >
                                <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                          <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Home</a>
                                          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
                                          <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a>
                                        </div>
                                      </nav>
                                      <div class="tab-content" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                                <ul class="mobile" >
                                                        <li class="chart_song_item">
                                                            <a href="#">
                                                                </a><div class="box-ranks"><a href="#">
                                                                    <figure>
                                                                        <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/110x110x1571217431/v1/album/s2/0/24/594/25774939.jpg" alt="" class="img-fluid">
                                                                        <span>
                                                                            01
                                                                        </span>
                                                                    </figure>
            
                                                                    </a><div class="infor_n"><a href="#">
                                                                        </a><h3><a href="#">
                                                                            </a><a href="#">
                                                                                Có Chàng Trai Viết Lên Cây
                                                                            </a>
            
                                                                        </h3>
                                                                        <p class="chat-song-top1">
                                                                            <a href="#">
                                                                                Phan Mạnh Quỳnh
                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            
                                                        </li>
                                                        <!-- end top1 -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt" id="red">
                                                                        02
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            Tình Nhân Ơi
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Superbrothers,
                                                                        </a>
                                                                        <a href="#">
                                                                            Orange,
                                                                        </a>
                                                                        <a href="#">
                                                                            Binz
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <!-- end top 2 -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        03
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            Em gi ơi
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Jack,
                                                                        </a>
                                                                        <a href="#">
                                                                            KICM,
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <!-- end top3  -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        04
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            Khó vẽ nụ cười
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            ĐạtG,
                                                                        </a>
                                                                        <a href="#">
                                                                            Du Duyên
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <!-- end -->
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                        <li class="chart_song_item">
                                                            <div class="box-item">
                                                                <div class="box_order_rank">
                                                                    <span class="chart_stt">
                                                                        05
                                                                    </span>
                                                                    <span class="order-rank-home order_zero">
            
                                                                    </span>
                                                                </div>
                                                                <div class="infor">
            
                                                                    <h3>
                                                                        <a href="#">
                                                                            lời yêu ngây dại
                                                                        </a>
            
                                                                    </h3>
                                                                    <p class="">
                                                                        <a href="#">
                                                                            Kha
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                        <a href="#">
            
                                                                        </a>
                                                                    </p>
            
            
                                                                </div>
                                                            </div>
            
                                                        </li>
                                                       
                                                        
                                                    </ul>
                                                    <div class="duma" >
                                                      
                                                            <i class="fas fa-arrow-down"></i>
                                                       </div>
                                                   
                                        </div>





                                        <!-- ssss -->
                                        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                            <ul class="mobile2">
                                                <li class="chart_song_item">
                                                    <a href="#">
                                                        </a><div class="box-ranks"><a href="#">
                                                            <figure>
                                                                <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/110x110x1571217431/v1/album/s2/0/24/594/25774939.jpg" alt="" class="img-fluid">
                                                                <span>
                                                                    01
                                                                </span>
                                                            </figure>
    
                                                            </a><div class="infor_n"><a href="#">
                                                                </a><h3><a href="#">
                                                                    </a><a href="#">
                                                                        Có Chàng Trai Viết Lên Cây
                                                                    </a>
    
                                                                </h3>
                                                                <p class="chat-song-top1">
                                                                    <a href="#">
                                                                        Phan Mạnh Quỳnh
                                                                    </a>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    
                                                </li>
                                                <!-- end top1 -->
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt" id="red">
                                                                02
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    Tình Nhân Ơi
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Superbrothers,
                                                                </a>
                                                                <a href="#">
                                                                    Orange,
                                                                </a>
                                                                <a href="#">
                                                                    Binz
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <!-- end top 2 -->
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                03
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    Em gi ơi
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Jack,
                                                                </a>
                                                                <a href="#">
                                                                    KICM,
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <!-- end top3  -->
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                04
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    Khó vẽ nụ cười
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    ĐạtG,
                                                                </a>
                                                                <a href="#">
                                                                    Du Duyên
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <!-- end -->
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                                <li class="chart_song_item">
                                                    <div class="box-item">
                                                        <div class="box_order_rank">
                                                            <span class="chart_stt">
                                                                05
                                                            </span>
                                                            <span class="order-rank-home order_zero">
    
                                                            </span>
                                                        </div>
                                                        <div class="infor">
    
                                                            <h3>
                                                                <a href="#">
                                                                    lời yêu ngây dại
                                                                </a>
    
                                                            </h3>
                                                            <p class="">
                                                                <a href="#">
                                                                    Kha
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                                <a href="#">
    
                                                                </a>
                                                            </p>
    
    
                                                        </div>
                                                    </div>
    
                                                </li>
                                               
                                                
                                            </ul>
                                            <div class="duma2" >
                                                    <i class="fas fa-arrow-down"></i>
                                               </div>
                                            
                                        </div>
                                        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"> 
                                            <ul class="mobile3">
                                            <li class="chart_song_item">
                                                <a href="#">
                                                    </a><div class="box-ranks"><a href="#">
                                                        <figure>
                                                            <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/110x110x1571217431/v1/album/s2/0/24/594/25774939.jpg" alt="" class="img-fluid">
                                                            <span>
                                                                01
                                                            </span>
                                                        </figure>

                                                        </a><div class="infor_n"><a href="#">
                                                            </a><h3><a href="#">
                                                                </a><a href="#">
                                                                    Có Chàng Trai Viết Lên Cây
                                                                </a>

                                                            </h3>
                                                            <p class="chat-song-top1">
                                                                <a href="#">
                                                                    Phan Mạnh Quỳnh
                                                                </a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                
                                            </li>
                                            <!-- end top1 -->
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt" id="red">
                                                            02
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                Tình Nhân Ơi
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Superbrothers,
                                                            </a>
                                                            <a href="#">
                                                                Orange,
                                                            </a>
                                                            <a href="#">
                                                                Binz
                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <!-- end top 2 -->
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            03
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                Em gi ơi
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Jack,
                                                            </a>
                                                            <a href="#">
                                                                KICM,
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <!-- end top3  -->
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            04
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                Khó vẽ nụ cười
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                ĐạtG,
                                                            </a>
                                                            <a href="#">
                                                                Du Duyên
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <!-- end -->
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                            <li class="chart_song_item">
                                                <div class="box-item">
                                                    <div class="box_order_rank">
                                                        <span class="chart_stt">
                                                            05
                                                        </span>
                                                        <span class="order-rank-home order_zero">

                                                        </span>
                                                    </div>
                                                    <div class="infor">

                                                        <h3>
                                                            <a href="#">
                                                                lời yêu ngây dại
                                                            </a>

                                                        </h3>
                                                        <p class="">
                                                            <a href="#">
                                                                Kha
                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                            <a href="#">

                                                            </a>
                                                        </p>


                                                    </div>
                                                </div>

                                            </li>
                                           
                                            
                                        </ul>
                                        <div class="duma3" >
                                                <i class="fas fa-arrow-down"></i>
                                           </div>
                                       
                                    </div>
                                      </div>
                        </div>
                        
                    </div>
                </div>
            </div>



        </section>





    </main>
    <!-- end main -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/album.blade.php ENDPATH**/ ?>