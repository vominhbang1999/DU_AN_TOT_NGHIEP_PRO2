<?php $__env->startSection('admin.admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách tin tức
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <td hidden>Id</td>
            <td>Tiêu đề tin</td>
            <td>Mô tả tin</td>
            <td>Hot</td>
            <td>Nội dung</td>
            <td>Hình</td>
            <td>Lượt xem</td>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $emp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td hidden><span class="text-ellipsis"><?php echo e($emp3->id); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->tieude_tintuc); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->mota_tintuc); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->tintuc_hot); ?> ★</span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->noidung_tintuc); ?></span></td>
            <td><span class="text-ellipsis"><img width="100" height="100" src="backend/images/<?php echo e($emp3->hinhanh_tintuc); ?>" alt=""></span></td>
            <td><span class="text-ellipsis"><?php echo e($emp3->luotxem); ?></span></td>

            <td>
                <a href="<?php echo e(URL::to('/edit_tintuc/'.$emp3->id)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <a onclick="return confirm('Bạn có muốn xóa không?')" href="<?php echo e(URL::to('/delete_tintuc/'.$emp3->id)); ?>" class="active" ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                </a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views/admin/qltintuc/ql_tintuc.blade.php ENDPATH**/ ?>