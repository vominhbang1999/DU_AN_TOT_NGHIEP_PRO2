<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <section class="detailtintuc mt-5">
                <div class="container">
                        <div class="row">
                            <div class="col-12 col-lg-9">


                                <div class="box-content">
                                    <h1 class="news-detail-box-title">
                                        <?php echo e($detailtintuc->title_tintuc); ?> </h1>
                                    <div class="news-detail-box-time">
                                        <?php echo e($detailtintuc->ngaydang); ?> </div>
                                    <div class="news-detail-box-m">
        
                                        <div class="news-social-link" id="news-social-link">
                                            <div style="margin-top: 15px" class="fb-like fb_iframe_widget" data-href="http://storediviss.com/" data-width="" data-layout="button" data-action="like" data-size="small" data-show-faces="true" data-share="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="action=like&amp;app_id=&amp;container_width=112&amp;href=http%3A%2F%2Fstorediviss.com%2F&amp;layout=button&amp;locale=vi_VN&amp;sdk=joey&amp;share=true&amp;show_faces=true&amp;size=small"><span style="vertical-align: bottom; width: 112px; height: 20px;"><iframe name="f2cfda9fafc8c2" width="1000px" height="1000px" title="fb:like Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v4.0/plugins/like.php?action=like&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D44%23cb%3Df3a20ad069f679%26domain%3D%26origin%3Dfile%253A%252F%252F%252Ff12cc4850e407d8%26relation%3Dparent.parent&amp;container_width=112&amp;href=http%3A%2F%2Fstorediviss.com%2F&amp;layout=button&amp;locale=vi_VN&amp;sdk=joey&amp;share=true&amp;show_faces=true&amp;size=small" style="border: none; visibility: visible; width: 112px; height: 20px;" class=""></iframe></span></div>
        
                                        </div>
                                        <div class="news-detail-box-des">
                                            "Chúng ta không cần là một người giỏi văn để có thể trở thành một người viết
                                            truyện…" - Hà Anh Tuấn đã chia sẻ như vậy vào đêm diễn Gấu tại Đà Lạt năm ngoái.
                                            Hình ảnh 5.000 khán giả che dù dưới mưa bay của Đà Lạt vẫn chưa phai mờ thì năm nay,
                                            người yêu “những nỗi buồn đẹp trong tình yêu” của nam ca sĩ lại đắm mình trong buổi
                                            hòa nhạc đúng sở trường lãng mạn mang tên Truyện Ngắn.
                                        </div>
                                        <div class="news-detail-box-content">
                                            <p dir="ltr">Ngay khi khởi động, cũng như các lần trước đây, vé của show trong đêm
                                                diễn tại Hội An và Hà Nội đã bán “hết sạch” chỉ sau... 5 phút. 12 năm làm nghề,
                                                không ra nhiều MV như các nghệ sĩ khác, tuy nhiên nam ca sĩ vẫn giữ được độ hot
                                                của mình bằng cách phát hành dự án âm nhạc như <em>See Sing Share</em> hay gây
                                                sốt không ngừng, trở thành “thánh sập phòng vé” nhờ chuỗi concert: <em>Fragile
                                                    Live Concert</em> (năm 2017), <em>RoMANce - Người đàn ông và bông hoa bên
                                                    ngực trái</em> và <em>Gấu Concert</em> tại Đà Lạt (năm 2018), <em>Truyện
                                                    Ngắn</em> (năm 2019). Lý do nào khiến giọng ca Sao Mai 2006 được yêu thích
                                                đến vậy?</p> <figure class="Sepia">
                                                    <img class="img-fluid"
                                                src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/haanhtuan-01.jpg"
                                                >
                                                </figure>
                                            <div>
                                                <p dir="ltr"><strong>Người nghệ sĩ tử tế trong âm nhạc</strong></p>
                                                <p dir="ltr"><strong><br></strong></p>
                                                <p dir="ltr">Hà Anh Tuấn được không ít đồng nghiệp, khán giả yêu mến, dành những
                                                    lời có cánh gọi anh là người nghệ sĩ tử tế trong âm nhạc. Sự tử tế của nam
                                                    ca sĩ không chỉ đến từ con người khi trích 200 triệu đồng từ số tiền thu lại
                                                    của đêm nhạc tại Hội An để dành tặng trung tâm bảo trợ trẻ em nhiễm chất độc
                                                    màu da cam tỉnh Quảng Nam với mong muốn các em có mùa trung thu ấm cúng hay
                                                    xin phép khán giả có mặt trong rạp hát Hội An được “mời” tất cả những khán
                                                    giả vì bất kì lý do nào mà không có cơ hội được sở hữu tấm vé, còn đứng
                                                    ngoài dõi theo Hà Anh Tuấn suốt 2 tiếng đầu của đêm nhạc vào bên trong sân
                                                    khấu. Lựa chọn hướng đi "sạch", "kín đáo" khi chỉ tập trung vào âm nhạc để
                                                    xây dựng hình tượng, thương hiệu riêng, mà còn từ sự tinh tế, tỉ mỉ từ những
                                                    điều nhỏ nhất mà anh dành cho âm nhạc.</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr">Nếu <em>Fragile</em> là lời tự tình&nbsp;với một bức thư tay cầu kỳ
                                                    được viết trên tấm plastic trong suốt, <em>Gấu</em> đưa người xem đến một
                                                    miền lãng mạn với bầu trời phủ kín những chiếc ô trong, thì <em>Truyện
                                                        Ngắn</em> lần này - một cuốn sổ bọc da với phần giới thiệu và lời bài
                                                    hát được trình diễn là tấm vé mà giọng ca sinh năm 1984 dành tặng người hâm
                                                    mộ tham gia đêm nhạc.</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr"><figure class="Brightness">
                                                    <img class="img-fluid"
                                                        src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/haanhtuan.jpg"
                                                        >
                                                </figure></p>
                                                <p dir="ltr">Trau chuốt từng câu hát, lời ca, các liveshow được biến thành những
                                                    câu chuyện, đến cả cảm xúc của fan cũng được Hà Anh Tuấn chú ý tới. Anh thậm
                                                    chí đã từng giúp một chàng trai cầu hôn bạn gái thành công ngay trong
                                                    liveshow <em>Romance</em> hồi tháng 4/2018 tại TP.HCM. Anh luôn thoải mái
                                                    tâm sự với những ca sĩ khách mời, bộc bạch với khán giả như những người bạn
                                                    bằng chất giọng trầm ấm, truyền cảm. Có lẽ bởi vậy mà trong mọi concert của
                                                    mình, anh luôn là người kết nối cảm xúc của âm nhạc và cuộc sống, của câu
                                                    chuyện từ ca khúc và câu chuyện đời thường, của ký ức lẫn hiện tại, của
                                                    người biểu diễn với khán giả của mình.</p>
                                                <div><figure class="Brightness"><img class="img-fluid"
                                                    src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/haanhtuan-03.jpg"
                                                    ></figure><br></div>
                                            </div>
                                            <div>
                                                <p dir="ltr"><strong><br></strong></p>
                                                <p dir="ltr"><strong>Gu âm nhạc đúng xu hướng và mang chất riêng</strong></p>
                                                <p dir="ltr"><strong><br></strong></p>
                                                <p dir="ltr">Lấy Acoustic và hát mộc làm chủ đạo, bắt đầu bằng <em>See Sing
                                                        Share</em> với âm hưởng lãng mạn, dịu nhẹ, bộ phối mềm, giai điệu không
                                                    quá dồn dập, cầu kì, Hà Anh Tuấn bắt trọn tâm lý và xu hướng của công chúng
                                                    khi luôn hướng tìm những thứ mộc mạc, giản dị để giải tỏa căng thẳng và xoa
                                                    dịu đầu óc.&nbsp;</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr">Không là thứ âm nhạc giản đơn, thuần pop sướt mướt đầu những năm
                                                    2000, chẳng phải chất nhạc phức tạp, đa chiều, đa nghĩa như Vintage, Bolero,
                                                    cũng không ‘bắt trend’ làn sóng nhạc điện tử du nhập từ quốc tế, “nhạc của
                                                    Hà Anh Tuấn không có nhạc vui hay nhạc buồn, mà đó là thứ nhạc hay” - Tuấn
                                                    nói.&nbsp;</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr">Hát nhạc của mình chưa đủ, anh còn khéo léo trong việc cover lại
                                                    những bài hit cũ dễ-gây-thương-nhớ như <em>Người tình mùa đông, Trái tim
                                                        ngục tù, Chỉ còn những mùa nhớ, Tình em ngọn nến, Nếu như, Tự khúc mùa
                                                        đông, Em đã yêu, Giấc mơ chỉ là giấc mơ</em>… hay hát cả một số bài nhạc
                                                    đậm tính thị trường như <em>Chiếc khăn gió ấm</em>, cover cả nhạc phim Hàn
                                                    Quốc như <em>Ngôi nhà hạnh phúc, Ước mơ vươn tới một ngôi sao, Hậu duệ mặt
                                                        trời</em>…&nbsp; trên âm hưởng Jazz/Blue/R&amp;B. Việc đánh trúng hoài
                                                    niệm của người nghe là một trong những chiến thuật đắc đạo của giọng ca gốc
                                                    Bắc.</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr">Dưới hình tượng lãng tử, không cầu kì, màu mè mà mang tính cổ điển,
                                                    xuất hiện tại những không gian mang tính thư giãn cao như quán cà phê mộc
                                                    theo kiểu Vintage, sân khấu ngoài trời với sự hiện hữu cao của thiên nhiên…
                                                    tất cả các nhân tố trên đã đánh trúng thị hiếu khán giả đương đại, mang lại
                                                    lượng fan hâm hộ đông đảo.</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr">Nếu là người đã thưởng thức âm nhạc của Hà Anh Tuấn trong đêm trước
                                                    đó, bạn sẽ dễ dàng nhận thấy mỗi năm một chất và sáng tạo hơn, nhưng sự văn
                                                    minh và tính nghệ thuật vẫn thấm đẫm trong từng đêm diễn. Dù đưa ra nhiều ca
                                                    khúc, sự thể nghiệm ấy vẫn được khán giả ngợi khen bởi các ca khúc thực sự
                                                    chất lượng.</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr"><strong>Hướng đi truyền thông độc đáo</strong></p>
                                                <p dir="ltr"><strong><br></strong></p>
                                                <p dir="ltr"><strong></strong>Không rầm rộ truyền thông, lăng xê bản thân, Hà
                                                    Anh Tuấn lựa chọn "đánh phá" khu vực ngoài "bảng xếp hạng" khi bỏ qua tiêu
                                                    chí nhiều view, comment tốt trên youtube hay đạt được thứ hạng cao ở trang
                                                    nghe nhạc trực tuyến. Độ hút của Hà Anh Tuấn ở chỗ, liveshow nào của anh
                                                    cũng "cháy vé", tốc độ "cháy vé" trung bình khoảng 30 phút dù giá vé không
                                                    hề rẻ.</p>
                                                <p dir="ltr"><br></p>
                                                <p dir="ltr">Một trong những bước đi khôn ngoan của Hà Anh Tuấn là việc ‘chọn
                                                    mặt gửi vàng’ khi luôn lựa chọn ‘ít nhưng chất’ ca sĩ hát chung với mình để
                                                    cho ra một sản phẩm độc lạ. Những cái tên sáng giá trong Vpop kể đến như
                                                    Nguyên Hà, Thùy Chi, Mỹ Tâm, Phan Mạnh Quỳnh, Hồ Ngọc Hà…&nbsp;Việc này còn
                                                    giúp Hà Anh Tuấn có thêm một số bài hit vốn đã in đậm trong lòng khán giả để
                                                    thể hiện, tạo nên hiệu ứng sân khấu tối ưu, gây nức lòng người
                                                    xem.&nbsp;&nbsp;</p>
                                                <p dir="ltr"><figure class="Brightness"><img class="img-fluid"
                                                    src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/mytam.jpg"
                                                     title="Mỹ Tâm "></figure><br></p>
                                                <p dir="ltr"><figure class="Brightness"><img class="img-fluid"
                                                    src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/hongocha.jpg"
                                                     title="Hồ Ngọc Hà"></figure><br></p>
                                                <p dir="ltr"><figure class="Brightness"><img class="img-fluid"
                                                    src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/phanmanhquynh.jpg"
                                                   
                                                    title="hay Phan Mạnh Quỳnh... đều là những khách mời trong concert của Hà Anh Tuấn"></figure><br>
                                                </p>
                                                <p dir="ltr">Hay gần đây nhất, sự kết hợp cùng Liên Bỉnh Phát, Phương Anh Đào,
                                                    Võ Điền Gia Huy, Lâm Thanh Mỹ... và cả tên tuổi gạo cội như NSƯT
                                                    Chiều&nbsp;Xuân, đạo diễn Cao Trung Hiếu trong việc ra mắt tác phẩm "chuyển
                                                    thể từ âm nhạc của dự án Hà Anh Tuấn hát Phan Mạnh Quỳnh" - một album nhạc
                                                    bằng hình ảnh đầu tiên.</p>
                                                <p dir="ltr"><figure class="Brightness"><img class="img-fluid"
                                                    src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/4953_DUC_6628.jpg"
                                                   ></figure></p>
                                                <p dir="ltr"><strong>Tạm kết</strong></p>
                                                <p dir="ltr"><strong></strong><span style="text-align:center">Với khán giả, phần
                                                        nhiều là đối tượng trẻ, Hà Anh Tuấn là hiện thân của âm nhạc văn minh và
                                                        trẻ trung, là nét chấm phá thanh tao trong cộng đồng âm nhạc đa sắc.
                                                    </span><span style="text-align:center">Mỗi năm, người hâm mộ nhạc Hà Anh
                                                        Tuấn lại chờ đón concert của anh. Đó không đơn giản là chờ đợi tên
                                                        concert, màu sắc, cách thể hiện, mà còn đợi cả một câu chuyện, tâm hồn
                                                        chan chứa cảm xúc riêng.</span></p>
                                                <p dir="ltr"><span style="text-align:center"><figure class="Brightness"><img class="img-fluid"
                                                    src="https://109cdf7de.vws.vegacdn.vn/v1/news/all/2709-haanhtuan/hat1.jpg"
                                                   
                                                    title=" “Tôi là một nghệ sĩ bình thường với thứ âm nhạc bình thường, nhưng ngày càng nhận những tình thân “bất thường”” - Hà Anh Tuấn."
                                                    alt=" “Tôi là một nghệ sĩ bình thường với thứ âm nhạc bình thường, nhưng ngày càng nhận những tình thân “bất thường”” - Hà Anh Tuấn."></figure><br></span>
                                                </p>
                                                <p dir="ltr" style="text-align:center"><span
                                                        style="text-align:center"></span><em
                                                        style="text-align:center">&nbsp;“Tôi là một nghệ sĩ bình thường với thứ
                                                        âm nhạc bình thường, nhưng ngày càng nhận những tình thân “bất thường””
                                                        - Hà Anh Tuấn.</em></p>
                                                <div style="text-align:center">
                                                    <div><br></div> <br> <br>
                                                </div> <br>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="row">
                                    <div class="col-12">
                                            <div class="box_title box_title_related_news" style="padding-top: 10px ; border-top: #5e6773 solid 1px;">
                                                    <h2 class="name">Tin mới</h2>
                                                </div>
                                    </div>
                                    <!-- START NEW TIN -->
                                    <div class="col-6 col-lg-3">
                                            <div class="news-list-sm-box-item">
                                                    <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky" class="news-list-sm-box-item-img "><figure>
                                                            <img  class="img-fluid " src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/270x270x1572245819/v1/news/s0/0/0/0/712.jpg" alt="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát" title="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát">
                                                    </figure></a>
                                                    <div class="info">
                                                        <p class="title">
                                                            <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky">‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát</a>
                                                        </p>
                                                    </div>
                                                </div>
                                    </div>
                                    <div class="col-6 col-lg-3">
                                            <div class="news-list-sm-box-item">
                                                    <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky" class="news-list-sm-box-item-img "><figure>
                                                            <img  class="img-fluid " src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/270x270x1572245819/v1/news/s0/0/0/0/712.jpg" alt="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát" title="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát">
                                                    </figure></a>
                                                    <div class="info">
                                                        <p class="title">
                                                            <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky">‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát</a>
                                                        </p>
                                                    </div>
                                                </div>
                                    </div>
                                    <div class="col-6 col-lg-3">
                                            <div class="news-list-sm-box-item">
                                                    <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky" class="news-list-sm-box-item-img "><figure>
                                                            <img  class="img-fluid " src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/270x270x1572245819/v1/news/s0/0/0/0/712.jpg" alt="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát" title="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát">
                                                    </figure></a>
                                                    <div class="info">
                                                        <p class="title">
                                                            <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky">‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát</a>
                                                        </p>
                                                    </div>
                                                </div>
                                    </div>
                                    <div class="col-6 col-lg-3">
                                            <div class="news-list-sm-box-item">
                                                    <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky" class="news-list-sm-box-item-img "><figure>
                                                            <img  class="img-fluid " src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/270x270x1572245819/v1/news/s0/0/0/0/712.jpg" alt="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát" title="‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát">
                                                    </figure></a>
                                                    <div class="info">
                                                        <p class="title">
                                                            <a href="https://nhac.vn/memories-maroon-5-loi-thi-tham-cua-nhung-hoi-uc-mat-mat-hs9Ky">‘Memories’ (Maroon 5): Lời thì thầm của những hồi ức mất mát</a>
                                                        </p>
                                                    </div>
                                                </div>
                                    </div>
                                  
                                    <!-- END LIST NEW TIN -->
                                    <div class="col-12">
                                            <div id="comment" class="box box-comment mgt-15 mb-5">
                                                    <div class="box_title">
                                                        <h2 class="name nobg" style="color: #fff; padding-top: 10px ; border-top: #5e6773 solid 1px;">Bình luận</h2>
                                                    </div>
                                                    <div class="box_content">
                                                        <textarea name="" id=""  rows="5" style="width: 100%;"></textarea>
                                                 	</div>
                                                </div>
                                    </div>
                                   
                                </div>

                              
        
        
        
                            </div>
                            <div class="col-12 col-lg-3">
                                <div class="box-aaa">
                                    
                                        <figure class="Brightness">
                                                <img src="https://109cdf7de.vws.vegacdn.vn/v1/banner/457.png?t=1569862800   " alt="" class="img-fluid">
                                            </figure>
                                            <div class="box_title">
                                                <h2 class="name"><a href="/hot-list" title="Chủ đề nổi bật">Chủ đề nổi bật</a></h2>
                                            </div>
                                            <figure  class="Brightness">
                                                <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/420x150x1/v1/topcontent/s1/0/0/0/142.jpg" class="img-fluid" >
                                            </figure>
                                            <figure  class="Brightness">
                                                <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/420x150x1/v1/topcontent/s1/0/0/0/232.jpg" class="img-fluid" alt="topic image">
                                            </figure>
                                            <figure  class="Brightness">
                                                <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/420x150x1/v1/topcontent/s1/0/0/0/193.jpg" class="img-fluid" alt="topic image">
                                            </figure>
                                            <figure  class="Brightness">
                                                <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/420x150x1/v1/topcontent/s1/0/0/0/163.jpg" class="img-fluid" >
                                            </figure>
                                            <figure  class="Brightness">
                                                <img src="https://109cdf7de.vws.vegacdn.vn/jXitUPK9cvjCkkVYrFPL/420x150x1/v1/topcontent/s1/0/0/0/220.jpg" class="img-fluid" >
                                            </figure>
                                </div>
                                
                            </div>
                        </div>
                    </div>
        </section>
        



    </main>
    <!-- END MAIN -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/detailtintuc.blade.php ENDPATH**/ ?>