<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
            <div class="banner-mv">
                <div class="overlay"></div>
                  <figure>
                      <img class="img-fluid" src="<?php echo e($mv_yeuthich->hinh_baihat); ?>">
                  </figure>
                <div class="container h-100">
                  <div class="d-flex h-100 text-center align-items-center">
                    <div class="w-100 text-white">
                      <img src="img/vip/logo.png" class="display-3" />
                      <h1 class="lead mb-0">Những MV hấp dẫn nhất đều có ở Music.vn</h1>
                    </div>
                  </div>
                </div>
            </div>
        <div class="container">
            <div class="row musicvideo">
                <div class="col-12 hb col-md-10 col-lg-8">
                    <div class="title row">
                        <nav class="navbar navbar-expand-lg">
                            <h1>
                                <a class="" href="#">Music Video</a>
                            </h1>
                            <div class="menu collapse navbar-collapse">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="active" href="<?php echo e(URL::asset('moinhat')); ?>">Mới nhất</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="active" href="<?php echo e(URL::asset('nghenhieu')); ?>">Nghe nhiều</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                        <hr>
                    </div>
                    <!-- ./ title -->
                    <div class="list-video row">
                        <?php $__currentLoopData = $mv_nghenhieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv_nghenhieu2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-md-4">
                                <div class="mv wow bounceInUp" data-wow-duration="2s" data-wow-delay=".3s">
                                        <a href="detailmv/<?php echo e($mv_nghenhieu2->id); ?>"><div class="video-img">
                                            <img src="<?php echo e(URL::asset($mv_nghenhieu2->hinh_baihat)); ?>" class="img-fluid" />
                                            <div class="overlay">
                                                <i class="icon fa fa-play"></i>
                                            </div>
                                        </div></a>
                                        <div class="text-center text">
                                            <a href="detailmv/<?php echo e($mv_nghenhieu2->id); ?>"><h5><?php echo e($mv_nghenhieu2->ten_baihat); ?></h5></a>

                                            <?php $__currentLoopData = $mv_nghenhieu2->casi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casi123): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="#"><p><?php echo e($casi123->hoten_casi); ?></p></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                        </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                    </div>
                    <!-- ./ list-video -->
                </div>
                <div class="col-12  col-md-2 col-lg-4 ht wow flipInX" data-wow-duration="2s" data-wow-delay=".3s">
                    <a href="#">
                        
                        <figure>
                                <img src="<?php echo e(URL::asset('img/mv/banner.jpg')); ?>"  class="img-fluid"/>
                        </figure>
                        
                        </a>
                </div>
            </div>
                 <div class="pages">
                        <ul class="nav justify-content-center">
                            <li class="">
                                <?php echo e($mv_nghenhieu->links()); ?>

                            </li>
                        </ul>
                    </div>
            <!-- ./ pages -->
        </div>
        <!-- ./ container -->
    </main>
    <!-- ./ main -->
    <!-- START FOOTER -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views/client/musicvideo.blade.php ENDPATH**/ ?>