<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- phần content -->
    <div class="container">
        <!-- slider carousel -->
        <div class="row mt-3">
            <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/slider-1.jpg" class="d-block img-fluid" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-2.jpg" class="d-block img-fluid" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-3.jpg" class="d-block img-fluid" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-4.jpg" class="d-block img-fluid" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-6.jpg" class="d-block img-fluid" alt="...">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
        <!-- kết thúc slider carousel -->

        <!-- phần nhạc HOT HIT -->
        <div class="chude">
            <!-- tiêu đề -->
            <div class="tieude mt-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="clearfix">
                            <div class="float-left">
                                <span>
                                <h2>Nhạc HOT HIT</h2>
                            </span>
                            </div>
                            <div class="float-right">
                                <span>
                                <a href="#" >Xem thêm&#62;&#62;</a>
                            </span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- kết thúc tiêu đề -->

            <!-- box chủ đề -->
            <div class="box-chude">
                <div class="row">
                    <div class="col-md-4">
                        <div class="box-con">
                            <div class="image">
                                <div class="thumb thumb-hover">
                                    <a href="#">
                                        <img width="100%" src="img/nhachot1.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="text">
                                <a href="#">
                                    <h5>Nhóm Nhạc</h5>
                                </a>
                                <span>                                      
                                    Nhóm nhạc là một tập hợp gồm nhiều thành viên. Nhóm nhạc không những cuốn hút bởi sự hòa hợp trong bè phối của từng bài hát, mà còn.
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box-con">
                            <div class="image">
                                <div class="thumb thumb-hover">
                                    <a href="#">
                                        <img width="100%" src="img/nhachot2.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="text">
                                <a href="#">
                                    <h5>Nhạc Hot 2019</h5>
                                </a>
                                <span>                                      
                                    Những năm 2019, Vpop bắt đầu xuất hiện những giọng hát trẻ vừa hội đủ các yếu tố xinh đẹp, hát hay, vũ đạo tốt. Hàng loạt những giọng 
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box-con">
                            <div class="image">
                                <div class="thumb thumb-hover">
                                    <a href="#">
                                        <img width="100%" src="img/nhachot3.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="text">
                                <a href="#">
                                    <h5>Nhạc Việt Năm 2000</h5>
                                </a>
                                <span>                                      
                                    Những năm 2000, Vpop bắt đầu xuất hiện những giọng hát trẻ vừa hội đủ các yếu tố xinh đẹp, hát hay, vũ đạo tốt, tất cả bắt đầu từ đây
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- kết thúc phần nhạc HOT HIT -->
        <div class="chude">
            <!-- tiêu đề -->
            <div class="tieude mt-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="clearfix">
                            <div class="float-left">
                                <span>
                                    <h2>Theo Dòng Cảm Xúc</h2>
                                </span>
                            </div>
                            <div class="float-right">
                                <span>
                                    <a href="#" >Xem thêm&#62;&#62;</a>
                                </span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- kết thúc tiêu đề -->
            <!-- theo dòng cảm xúc -->

                <div class="box-chude">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="box-con">
                                <div class="image">
                                    <div class="thumb thumb-hover">
                                        <a href="#">
                                            <img width="100%" src="img/camxuc1.jpg" alt="">
                                        </a>
                                    </div>
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <h5>Nhạc Cho Ngày Mưa</h5>
                                    </a>
                                    <span>                                      
                                        Mưa là nguồn cảm hứng sáng tác vô tận của các nhạc sĩ. Cùng Nhac.vn lắng nghe những ca khúc đầy cảm xúc lấy cảm hứng từ những giọt mưa 
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-con">
                                <div class="image">
                                    <div class="thumb thumb-hover">
                                        <a href="#">
                                            <img width="100%" src="img/camxuc2.jpg" alt="">
                                        </a>
                                    </div>
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <h5>Nhạc Dành Cho FA</h5>
                                    </a>
                                    <span>                                      
                                        FA viết tắt của Forever Alone chỉ những người cô đơn, lẻ bóng, nói chung là những người chưa có người yêu, hiểu được nỗi lòng và tâm sự 
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-con">
                                <div class="image">
                                    <div class="thumb thumb-hover">
                                        <a href="#">
                                            <img width="100%" src="img/camxuc3.jpg" alt="">
                                        </a>
                                    </div>
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <h5>Instrumental</h5>
                                    </a>
                                    <span>                                      
                                        Nhạc không lời hay nhạc hòa tấu nhẹ nhàng luôn có tác dụng rất tốt trong việc giải tỏa căng thẳng đầu óc sau những giờ học tập và lao động
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <!-- kết thúc theo dòng cảm xúc -->

        
        <!-- kết thúc phần nhạc thời gian -->

        
        <!-- kết thúc nhạc cho hoạt động -->

        
        <!-- kết thúc nhạc yêu thích -->

        
        <!-- kết thúc sự kiện hot -->

        
        <!-- kết thúc chương trình hot -->>
    </div>
    <!-- kết thúc phần content -->


<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NHAC.VN\resources\views///client/chude.blade.php ENDPATH**/ ?>