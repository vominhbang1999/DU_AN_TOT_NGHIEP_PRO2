<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <div class="bgvip">
            <div class="bgcolor">
                <div class="container">
                    <img src="img/vip/logo.png" />
                    <h1>Đặc quyền tài khoản VIP</h1>
                    <div class="link">
                        <a href="#">Mua ngay</a>
                    </div>
                </div>
            </div>
        </div>
        <section class="edit">


            <div class="container">
                <div class="logo text-center">
                    <h1>Chọn gói VIP phù hợp với bạn để trải nghiệm âm nhạc trọn vẹn nhất</h1>
                </div>
                <div class="table-vip row">
                    <div class="col-12 col-md-4" >
                       <div class="vip  wow rotateInDownLeft" data-wow-duration="1s" data-wow-delay=".3s">
                            <div class="title">
                                    <h1>VIP NGÀY</h1>
                                    <p>Thanh toán bằng tài khoản điện thoại</p>
                                </div>
                                <div class="card-vip row">
                                    <div class="money">
                                        <h1>2.000đ</h1>
                                        <p>Mobifone/Vinaphone</p>
                                    </div>
                                    <div class="line"></div>
                                    <div class="money">
                                        <h1>3.000đ</h1>
                                        <p>Viettel/Vietnammobile</p>
                                    </div>
                                </div>
                                <figure>
                                        <img src="img/vip/egg.png" class="img-fluid" />
                                </figure>
                               
                                <ul>
                                    <li>Tải nhạc quốc tế 128kbps, tải nhạc Việt Nam 320kbps</li>
                                    <li>Nghe nhạc độc quyền dành riêng cho VIP</li>
                                    <li>Miễn phí data 3G/4G khi nghe nhạc tại nhac.vn</li>
                                </ul>
                                <a class="buy" href="#">Mua gói</a>
                       </div>
                       
                       
                     
                    </div>
                    <div class=" col-12 col-md-4 " >
                        <div class="vip wow rotateInDownLeft"   data-wow-duration="1s" data-wow-delay=".6s"  >
                                <div class="title">
                                        <h1>VIP TUẦN</h1>
                                        <p>Thanh toán bằng tài khoản điện thoại</p>
                                    </div>
                                    <div class="card-vip row">
                                        <div class="money">
                                            <h1>10.000đ</h1>
                                            <p>Mobi/Vina</p>
                                        </div>
                                        <div class="line"></div>
                                        <div class="money">
                                            <h1>15.000đ</h1>
                                            <p>Viettel Mobile</p>
                                        </div>
                                    </div>
                                    <figure>
                                            <img src="img/vip/chickenegg.png" class="img-fluid" />
                                    </figure>
                                   
                                    <ul>
                                        <li>Tải nhạc quốc tế 320kbps, tải nhạc Việt Nam lossless</li>
                                        <li>Nghe nhạc độc quyền dành riêng cho VIP</li>
                                        <li>Miễn phí data 3G/4G khi nghe nhạc tại nhac.vn</li>
                                    </ul>
                                    <a class="buy" href="#">Mua gói</a>
                        </div>
                
                    </div>
                    <div class=" col-12 col-md-4" >
                        <div class="vip  wow rotateInDownLeft" data-wow-duration="1s" data-wow-delay=".9s">
                                <div class="title">
                                        <h1>VIP THÁNG</h1>
                                        <p>Thanh toán bằng nhiều hình thức</p>
                                    </div>
                                    <div class="card-vip row">
                                        <div class="bank">
                                            <h1>30.000đ</h1>
                                            <p>Thẻ cào/ATM/e-Banking/Ví điện tử…</p>
                                        </div>
                                    </div>
                                    <figure>
                                            <img src="img/vip/chicken.png" class="img-fluid" /> 
                                    </figure>
                                    
                                    <ul>
                                        <li>Tải nhạc việt nam và quốc tế chất lượng lossless</li>
                                        <li>Nghe nhạc độc quyền dành riêng cho VIP</li>
                                    </ul>
                                    <a class="buy" href="#">Mua gói</a>
                        </div>
                        
                    
                    </div>
                </div>
                <!-- ./ table-vip -->
            </div>
        </section>
       
        <!-- ./ container -->
        <section class="blockersd">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="row d-flex align-items-center justify-content-center">
                            <div class="col-12 col-lg-6 ">
                                <figcaption>
                                        <h1>100%</h1>
                        <h2>nhạc chất lượng cao, không quảng cáo</h2>
                        <p>Tại nhac.vn, những bài hát luôn được kiểm duyệt trước khi phát hành</p>
                        <p>để đảm bảo chất lượng tốt nhất</p>
                        <p>Trải nghiệm âm thanh luôn được quan tâm ở mức tối đa.</p>
                                </figcaption>

                            </div>
                            <div class="col-12 col-lg-6">

                                <figure class="text-right">
                                    <img src="img/vip/high.png" alt="" class="img-fluid" >
                                </figure>

                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="row ">
                    <div class="col-12">
                        <div class="row d-flex align-items-center justify-content-center">
                            <div class="col-12 col-lg-6 custom">
                                    <figure class="">
                                            <img src="img/vip/uudai3.png" alt="" class="img-fluid" >
                                        </figure>
                            </div>
                            <div class="col-12 col-lg-6">
                                <figcaption>
                                        <h1>Nhạc độc quyền</h1>
                                        <h2>chỉ có trên music.vn</h2>
                                        <p>Khám phá và thưởng thức những ca khúc đặc biệt không có ở bất kì</p>
                                        <p>nơi nào khác</p>
                                </figcaption>
                            </div>
                        </div>
                    </div>
                            
                    </div>
                <div class="row ">
                    <div class="col-12">
                        <div class="row d-flex align-items-center justify-content-center">
                           
                            <div class="col-12 col-lg-6 ">
                                <figcaption>
                                        <h1>Mọi lúc, mọi nơi</h1>
                                        <h2>miễn phí data 3G/4G</h2>
                                        <p>Không còn phải lo về giá hay dung lượng bộ nhớ với gói VIP đăng kí</p>
                                        <p>bằng tài khoản điện thoại. Âm nhạc từ nhac.vn luôn luôn sẵn sàng</p>
                                        <p>đồng hành cùng bạn tới bất cứ đâu.</p>
                                </figcaption>
                            </div>
                            <div class="col-12 col-lg-6">
                                <figure class="">
                                        <img src="img/vip/uudai2.png" alt="" class="img-fluid" >
                                    </figure>
                        </div>
                        </div>
                    </div>
                            
                    </div>
                <div class="row ">
                    <div class="col-12">
                        <div class="row d-flex align-items-center justify-content-center">
                            <div class="col-12 col-lg-6 custom">
                                    <figure class="">
                                            <img src="img/vip/uudai4.png" alt="" class="img-fluid" >
                                        </figure>
                            </div>
                            <div class="col-12 col-lg-6">
                                <figcaption>
                                        <h1>Hàng trăm ưu đãi</h1>
                                        <h2>ăn uống, sự kiện, quà tặng ngôi sao...</h2>
                                        <p>Tận hưởng quyền lợi tối đa khi là VIP của music.vn</p>
                                        <p>Không chỉ là nghe nhạc</p>
                                </figcaption>
                            </div>
                        </div>
                    </div>
                            
                    </div>
            </div>



        </section>
        
    </main>
    <!-- ./ main -->
   <!-- START FOOTER -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/vip.blade.php ENDPATH**/ ?>