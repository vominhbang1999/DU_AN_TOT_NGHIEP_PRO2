<?php echo $__env->make('client.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- phần content -->
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="banner-khuyenmai">
                    <div class="gift-left">
                    </div>
                    <div class="gift-text">
                        <p class="title-1">Nhập Mã Khuyễn Mãi</p>
                        <p class="title-2">
                            Nhập ngay mã khuyễn mãi để tận hưởng những<br/> ưu đãi VIP của nhac.vn
                        </p>
                        <div class="gift-box">
                            <input type="text" class="gift-input">
                            <button type="button" class="gift-btn">
                                <img src="img/giftcode-btn.png" alt="">
                            </button>
                        </div>
                        <p class="title-3">Lưu ý: Các kí tự có thể gây nhầm lẫn: 0/0, 1/1, 5/5, 1/1,...</p>
                        <p class="title-4">
                            <a href="#">Mã khuyến mãi này nhận ở đâu ?</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="title-tieude mt-5">
                    <p>Tin tức từ Nhac.vn</p>
                </div>
            </div>
        </div>
        <div class="tintuc">

            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <div class="box-tintuc ">
                        <div class="row text-center">
                            <div class="col-md-6">
                                <div class="tintuc-image">
                                    <a href="#">
                                        <figure>
                                            <img class="img-fluid" src="img/khuyenmai8.jpg" alt="">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tintuc-text">
                                    <p class="title">
                                        <a href="#">Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu </a>
                                    </p>
                                    <p class="time">2019-07-05 16:03:06</p>
                                    <p class="intro">Vắng bóng sau một năm, đúng 20h ngày 1/7, Sơn Tùng M-TP đã chính thức phát hành MV “Hãy trao cho </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="box-tintuc ">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tintuc-image">
                                    <a href="#">
                                        <img class="img-fluid" src="img/khuyenmai8.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tintuc-text">
                                    <p class="title">
                                        <a href="#">Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu </a>
                                    </p>
                                    <p class="time">2019-07-05 16:03:06</p>
                                    <p class="intro">Vắng bóng sau một năm, đúng 20h ngày 1/7, Sơn Tùng M-TP đã chính thức phát hành MV “Hãy trao cho </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="box-tintuc ">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tintuc-image">
                                    <a href="#">
                                        <img class="img-fluid" src="img/khuyenmai8.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tintuc-text">
                                    <p class="title">
                                        <a href="#">Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu </a>
                                    </p>
                                    <p class="time">2019-07-05 16:03:06</p>
                                    <p class="intro">Vắng bóng sau một năm, đúng 20h ngày 1/7, Sơn Tùng M-TP đã chính thức phát hành MV “Hãy trao cho </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="box-tintuc ">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tintuc-image">
                                    <a href="#">
                                        <img class="img-fluid" src="img/khuyenmai8.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tintuc-text">
                                    <p class="title">
                                        <a href="#">Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu </a>
                                    </p>
                                    <p class="time">2019-07-05 16:03:06</p>
                                    <p class="intro">Vắng bóng sau một năm, đúng 20h ngày 1/7, Sơn Tùng M-TP đã chính thức phát hành MV “Hãy trao cho </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="box-tintuc ">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tintuc-image">
                                    <a href="#">
                                        <img class="img-fluid" src="img/khuyenmai8.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tintuc-text">
                                    <p class="title">
                                        <a href="#">Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu </a>
                                    </p>
                                    <p class="time">2019-07-05 16:03:06</p>
                                    <p class="intro">Vắng bóng sau một năm, đúng 20h ngày 1/7, Sơn Tùng M-TP đã chính thức phát hành MV “Hãy trao cho </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="box-tintuc ">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tintuc-image">
                                    <a href="#">
                                        <img class="img-fluid" src="img/khuyenmai8.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tintuc-text">
                                    <p class="title">
                                        <a href="#">Lý giải "Hãy trao cho anh" - cơn sốt toàn cầu </a>
                                    </p>
                                    <p class="time">2019-07-05 16:03:06</p>
                                    <p class="intro">Vắng bóng sau một năm, đúng 20h ngày 1/7, Sơn Tùng M-TP đã chính thức phát hành MV “Hãy trao cho </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- kết thúc phần content -->
    <!-- START FOOTER -->
<?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views///client/makhuyenmai.blade.php ENDPATH**/ ?>