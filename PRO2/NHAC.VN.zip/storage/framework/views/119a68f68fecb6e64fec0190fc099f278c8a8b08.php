

 <div class="col-md-3">
        <div class="circular-bar">
            <div class="circular-bar-chart">
            	<figure>
            		<img class="img-fluid" src='<?php echo e($detailcasi->avatar_casi); ?>'
            	</figure>
                <strong><?php echo e($detailcasi->hoten_casi); ?></strong>
                <?php $__currentLoopData = $detailcasi->baihat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baihat123): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<label><span class="percent"></span><?php echo e($baihat123->ten_baihat); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
 </div>

<?php /**PATH C:\xampp\htdocs\PRO2\NHAC.VN\resources\views/client/home.blade.php ENDPATH**/ ?>