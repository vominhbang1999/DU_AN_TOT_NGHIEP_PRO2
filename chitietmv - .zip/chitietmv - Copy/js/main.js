$(document).ready(function () {
    if ($(window).width() < 567) {
       $('#focus').addClass('focus1');
     }
     
});