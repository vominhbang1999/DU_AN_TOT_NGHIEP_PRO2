<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>INSERT</title>
</head>
<body>
    <div class="container">
        <div class="row mt-5"></div>
        <div class="row mt-5">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <form role="form" action="store" method="get">
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Tên album</label>
                        <input type="text" class="form-control" name='ten_album' id="exampleFormControlInput1" >
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Hot</label>
                        <select class="form-control"  name='hot_album' id="exampleFormControlInput1" >
                            <option value="1">1 Star</option>
                            <option value="2">2 Star</option>
                            <option value="3">3 Star</option>
                            <option value="4">4 Star</option>
                            <option value="5">5 Star</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Hình</label>
                        <input type="text" class="form-control" name='hinh_album' id="exampleFormControlInput1">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Mô tả</label>
                        <input type="text" class="form-control" name='mota_album' id="exampleFormControlInput1" >
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Ngày cập nhật</label>
                        <input type="date" class="form-control" name='ngaycapnhat_album' id="exampleFormControlInput1" >
                    </div>
                    
                    <input type="submit" name="save" class="btn btn-light" value='INSERT'/>
                </form>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>

</body>
</html>