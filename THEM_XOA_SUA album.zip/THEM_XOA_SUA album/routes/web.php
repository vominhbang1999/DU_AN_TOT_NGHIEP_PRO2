<?php
use App\Http\Controllers\quanly;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('insert', 'quanlyalbum@form_insert');

Route::get('store', 'quanlyalbum@store');

Route::get('dulieu', 'quanlyalbum@index');

Route::get('edit/{id}', 'quanlyalbum@form_edit');

Route::post('save/{id}', 'quanlyalbum@update');

Route::get('delete/{id}', 'quanlyalbum@delete');
