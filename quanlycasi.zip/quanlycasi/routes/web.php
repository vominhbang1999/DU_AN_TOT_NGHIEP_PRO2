<?php
use App\Http\Controllers\quanly;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('insert', 'quanlycasi@form_insert');

Route::get('store', 'quanlycasi@store');

Route::get('dulieu', 'quanlycasi@index');

Route::get('edit/{id}', 'quanlycasi@form_edit');

Route::post('save/{id}', 'quanlycasi@update');

Route::get('delete/{id}', 'quanlycasi@delete');
