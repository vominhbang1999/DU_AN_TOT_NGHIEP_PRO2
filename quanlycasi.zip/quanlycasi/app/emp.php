<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class emp extends Model 
    {
        protected $primaryKey='id_casi';
        protected $table='casi';
        protected $filltable=array('hoten_casi','hot_casi','hinh_casi','gioithieu_casi');
    }

?>